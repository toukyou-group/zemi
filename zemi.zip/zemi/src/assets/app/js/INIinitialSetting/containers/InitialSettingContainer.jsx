
import InitialSettingHeader from '../components/InitialSettingHeader.jsx';
import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {setImageName} from '../actions/sync.js';
class App extends Component {
  render() {
    return (
    <div className='modal'>
        {this.props.children && React.cloneElement(this.props.children, this.props)}
		<InitialSettingHeader/>
    </div>
  );
  }
}

App.propTypes = {
  children: PropTypes.node
};

function mapStateToProps(state) {
  return state;
}

export default connect(mapStateToProps)(App);
