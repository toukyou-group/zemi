
import LearningSettingHeader from '../components/learningSettingComponent/LearningSettingHeader.jsx';
import LearningSettingTable from '../components/learningSettingComponent/LearningSettingTable.jsx';
import LearningSettingFooter from '../components/learningSettingComponent/LearningSettingFooter.jsx';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import React, {Component, PropTypes} from 'react';
import {setImageName} from '../actions/sync.jsx';

class LearningSettingContainer extends Component{
  render(){
    const {imageNames} = this.props;
    return(
		<div className='modal-inner'>
			<LearningSettingHeader imageName={imageNames.imageName} setImageName={this.props.setImageName}/>
			<LearningSettingTable/>
			<LearningSettingFooter />
		</div>
		);
  }
}

LearningSettingContainer.propTypes = {
  setImageName: PropTypes.func.isRequired,
  imageNames: PropTypes.object.isRequired
};

function mapStateToProps(state) {
  return state;
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({
    setImageName: setImageName
  }, dispatch);
}
export default connect(mapStateToProps, mapDispatchToProps)(LearningSettingContainer);
