import React, {Component} from 'react';
export default class LearningSettingFooter extends Component{
  render() {
    return (
        <div className="footer">
            <a href="javascript:void(0);" className="btn btn-raised back">&lt;戻る</a>
            <a href="javascript:void(0);" className="btn btn-raised next">&gt;次へ</a>
        </div>
        );
  }
}
