import React, {Component} from 'react';

export default class InitialSettingHeader extends Component{
  render() {
    return (
            <ul className="progress-list">
                <li><a href="javascript:void(0);" className="btn btn-raised">ニックネーム</a></li>
                <li><a href="javascript:void(0);" className="btn btn-raised">目標設定</a></li>
                <li><a href="javascript:void(0);" className="btn btn-raised">定期テスト日程</a></li>
                <li><a href="javascript:void(0);" className="btn btn-raised btn-primary">学習設定</a></li>
                <li><a href="javascript:void(0);" className="btn btn-raised">取り組み時間</a></li>
            </ul>
        );
  }
}
