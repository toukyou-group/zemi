import React, {Component, PropTypes} from 'react';
export default class LearningSettingHeader extends Component{
  render(){
    return (
            <div>
              <h1>{this.props.imageName}</h1>
              <h1>学習設定をしよう！</h1>
              <div className="teacher"></div>
              <p className="offer">キミに最適な「学習カリキュラム」を作成するため、各教科に必要な設定をしよう。</p>
              <p className="note">※設定内容は「教室」でいつでも変更できます。</p>
              <input type='button' value='ヘルプ' onClick={()=>{this.onHelperTap();}}/>
            </div>
        );
  }
  onHelperTap(){
    this.props.setImageName('somename');
  }
}

LearningSettingHeader.propTypes = {
  imageName: PropTypes.string.isRequired,
  setImageName: PropTypes.func.isRequired
};
