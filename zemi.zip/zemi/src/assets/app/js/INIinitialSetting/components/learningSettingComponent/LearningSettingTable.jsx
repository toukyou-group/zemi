import React, {Component} from 'react';
export default class LearningSettingTable extends Component{
  render() {
    return (
      <div>
          <table className="subjects">
            <thead>
              <tr>
                <th>教科</th>
                <th>レベル</th>
                <th>講義/演習</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><i className="subject E">&nbsp;</i>英語<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject M">&nbsp;</i>数学<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject J">&nbsp;</i>国語<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject R">&nbsp;</i>理科<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject S">&nbsp;</i>社会<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
            </tbody>
          </table>
          </div>
        );
  }
}
