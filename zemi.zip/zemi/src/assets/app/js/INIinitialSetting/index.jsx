import React from 'react';
import {render} from 'react-dom';
import {Provider} from 'react-redux';
import {Router, Route, IndexRoute, IndexRedirect, browserHistory, hashHistory} from 'react-router';

import store from './store/initialSettingStore.jsx';
import InitialSettingContainer from './containers/InitialSettingContainer.jsx';
import LearningSettingContainer from './containers/LearningSettingContainer.jsx';
render(
    <Provider store={store}>
      <div>
        <Router history = { browserHistory }>
          <Route path='/' component={InitialSettingContainer}>
            <IndexRoute path='learningSetting' component={LearningSettingContainer}/>
          </Route>
       </Router>
      </div>
    </Provider>,
    document.getElementById('reactroot')
);
