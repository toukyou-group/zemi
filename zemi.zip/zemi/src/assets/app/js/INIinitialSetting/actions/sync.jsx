export const TEST = 'TEST';

export const setImageName = (imageName) => {
  return {
    type: TEST,
    imageName: imageName
  };
};
