import {createStore, compose, applyMiddleware} from 'redux';
import rootReducer from '../reducers';
import thunk from "redux-thunk";
import {routerMiddleware} from "react-router-redux";

export default function configureStore(history, preloadedState) {
  return createStore(
    rootReducer,
    preloadedState,
    applyMiddleware(
      thunk,
      routerMiddleware(history)
    )
  );
}

