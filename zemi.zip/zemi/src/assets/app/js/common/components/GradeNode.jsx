import React, {Component, PropTypes} from "react";

export class GradeNode extends Component {

  render() {
    return this.props.children;
  }
}

GradeNode.propTypes = {
  renderGrades: PropTypes.string,
  children: PropTypes.node
};

