import React, {PropTypes, Component} from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';

export default class ErrorDialog extends Component {

  render() {
    let actions = [
      <FlatButton
        label="OK"
        primary={true}
        onTouchTap={this.props.closeAction}
        />
    ];
    return (
      <Dialog
        title="Error"
        actions={actions}
        modal={true}
        open={this.props.error.display}
        >
        <div>
          <div>
            エラーコード:{this.props.error.code}
          </div>
          <div>
            メッセージ:{this.props.error.message}
          </div>
        </div>
      </Dialog>
    );
  }
}

ErrorDialog.propTypes = {
  error: PropTypes.object.isRequired,
  closeAction: PropTypes.func.isRequired
};

