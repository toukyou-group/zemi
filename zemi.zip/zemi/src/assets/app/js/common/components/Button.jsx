import React, {Component, PropTypes} from "react";

import {log} from "common/utils";


class Button extends Component {


  //----------------------------------------------------------------------------------------------------
  /// constructor
  constructor(props) {
    super(props);
  }


  //----------------------------------------------------------------------------------------------------
  /// lifecycle
  componentDidMount() {
    $(this.refs.el).ripples();
  }


  //----------------------------------------------------------------------------------------------------
  /// render
  render() {
    let props = _.assign({}, this.props);
    let Tagname = props.tagname || "a";
    delete props.tagname;
    props.className = props.className + " reacted";
    return (
      <Tagname {...props} ref="el">{this.props.children}</Tagname>
    );
  }
  //----------------------------------------------------------------------------------------------------
}

Button.propTypes = {
  children: PropTypes.any,
  tagname: PropTypes.string
};


export default Button;
