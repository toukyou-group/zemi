import React, {PropTypes} from "react";

export default class Component extends React.Component {
}

Component.propTypes = {
};

