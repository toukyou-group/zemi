import React, {Component, PropTypes} from "react";

export class GradeFilter extends Component {

  render() {

    if(!this.props.children) {
      return null;
    }

    let nodes = this.props.children.filter(node => {
      return (!node.props.renderGrades || node.props.renderGrades.indexOf(this.props.grade) >= 0);
    });

    return (nodes.length && nodes[0]) || null;
  }
}

GradeFilter.propTypes = {
  grade: PropTypes.string.isRequired,
  children: PropTypes.array
};

