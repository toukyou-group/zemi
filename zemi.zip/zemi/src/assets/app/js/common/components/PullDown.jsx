import React, {PropTypes} from "react";
import Component from "./Component";

export class PullDown extends Component {

  render() {
    let options = this.props.options.map(option => {
      return (
        <option value={option.code} key={option.code}>{option.value}</option>
      );
    });

    let className = "component_pulldown " + (this.props.className || "");

    return (
      <select className={className} value={this.props.value} onChange={this.props.onChange}>
        {options}
      </select>
    );
  }
}

PullDown.propTypes = {
  value: PropTypes.string,
  options: PropTypes.array,
  className: PropTypes.string,
  onChange: PropTypes.func
};

