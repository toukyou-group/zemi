import {ACTIONS} from '../constants/Constants';
import {createAction} from 'redux-actions';

export const showErrorDialog = createAction(ACTIONS.SHOW_ERROR_DIALOG, err => err);
export const closeErrorDialog = createAction(ACTIONS.CLOSE_ERROR_DIALOG);

