import superagent from "superagent";
import superagentMocker from "superagent-mocker";

let mock = superagentMocker(superagent);
mock.timeout = 2000;

mock.post("/api/change_nickname", function(req) {
  let error = void 0;
  if (req.body.nickname[0] == "E" || req.body.nickname[1] == "F") {
    error = {
      code: "-1111",
      message: req.body.nickname + "が無効です"
    };
  }
  return {
    error,
    result: {
      nickname: req.body.nickname
    }
  };
});

mock.post("/api/getLearningSubjectMaster", function(req) {

  return {
    "jsonrpc": "2.0",
    "id": "unit-test-json-id",
    "result": {
      "learningSubjectMaster": [
        {
          "subjectCode": "E",
          "subjectName": "英語",
          "displayOrder": 1,
          "subjectDetail": [
            {
              "subjectDetailCode": "00",
              "subjectDetailName": "共通"
            }
          ]
        },
        {
          "subjectCode": "M",
          "subjectName": "数学",
          "displayOrder": 2,
          "subjectDetail": [
            {
              "subjectDetailCode": "00",
              "subjectDetailName": "共通"
            }
          ]
        },
        {
          "subjectCode": "J",
          "subjectName": "国語",
          "displayOrder": 3,
          "subjectDetail": [
            {
              "subjectDetailCode": "00",
              "subjectDetailName": "共通"
            }
          ]
        },
        {
          "subjectCode": "R",
          "subjectName": "理科",
          "displayOrder": 4,
          "subjectDetail": [
            {
              "subjectDetailCode": "00",
              "subjectDetailName": "共通"
            }
          ]
        },
        {
          "subjectCode": "S",
          "subjectName": "社会",
          "displayOrder": 5,
          "subjectDetail": [
            {
              "subjectDetailCode": "00",
              "subjectDetailName": "共通"
            }
          ]
        }
      ]
    }
  };
});

mock.post("/api/getLearningSetting", function(req) {
  return {
    "jsonrpc": "2.0",
    "id": "unit-test-json-id",
    "result": {
      "learningSetting": [
        {
          "subjectCode": "E",
          "subjectName": "英語",
          "course": "F98",
          "lectureExercisesKubun": "1"
        },
        {
          "subjectCode": "M",
          "subjectName": "数学",
          "course": "L99",
          "lectureExercisesKubun": "2"
        },
        {
          "subjectCode": "J",
          "subjectName": "国語",
          "course": "F02",
          "lectureExercisesKubun": "1"
        },
        {
          "subjectCode": "R",
          "subjectName": "理科",
          "course": "F01",
          "lectureExercisesKubun": "1"
        },
        {
          "subjectCode": "S",
          "subjectName": "社会",
          "course": "F01",
          "lectureExercisesKubun": "2"
        }
      ],
      "screenDisplayCodeMasterInformation": [
        {
          "displayClass": "0000000002",
          "codeInformation": [
            {
              "code": "0",
              "value": "未選択"
            },
            {
              "code": "1",
              "value": "講義"
            },
            {
              "code": "2",
              "value": "演習"
            }
          ]
        },
        {
          "displayClass": "0000000001",
          "codeInformation": [
            {
              "code": "F01",
              "value": "ハイレベル"
            },
            {
              "code": "F02",
              "value": "スタンダード"
            },
            {
              "code": "F98",
              "value": "ハイレベル"
            },
            {
              "code": "F99",
              "value": "スタンダード"
            }
          ]
        },
        {
          "displayClass": "0000000005",
          "codeInformation": [
            {
              "code": "L01",
              "value": "ハイレベル"
            },
            {
              "code": "L02",
              "value": "スタンダード"
            },
            {
              "code": "L98",
              "value": "ハイレベル"
            },
            {
              "code": "L99",
              "value": "スタンダード"
            }
          ]
        },
        {
          "displayClass": "0000000006",
          "codeInformation": [
            {
              "code": "ｷ01",
              "value": "ハイレベル"
            },
            {
              "code": "ｷ02",
              "value": "スタンダード（体系型）"
            },
            {
              "code": "ｷ03",
              "value": "スタンダード（検定型）"
            },
            {
              "code": "ｷ91",
              "value": "ハイレベル"
            },
            {
              "code": "ｷ92",
              "value": "スタンダード（体系型）"
            },
            {
              "code": "ｷ93",
              "value": "スタンダード（検定型）"
            }
          ]
        },
        {
          "displayClass": "0000000007",
          "codeInformation": [
            {
              "code": "0",
              "value": "未選択"
            },
            {
              "code": "F01",
              "value": "ハイレベル"
            },
            {
              "code": "F02",
              "value": "スタンダード"
            }
          ]
        }
      ]
    }
  };

});

mock.post("/api/registerInitialSetting", function(req) {
  return {result: "OK"};
});


export default mock;
