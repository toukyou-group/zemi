//----------------requestApi用
import superagent from "superagent";
import mocker from "./mocker";

//---mock--dev
import superagentPromisePlugin from "superagent-promise-plugin";
superagentPromisePlugin.Promise = Promise;
let request = superagentPromisePlugin.patch(superagent);
//----------------requestApi用
//-----wording-----
import WordingS from "../constants/WordingS";
import WordingH from "../constants/WordingH";
//-----wording-----

export {Enum} from "./Enum";

export function log() {
  console.log(...arguments); // eslint-disable-line no-console
}

export function saveToStorage(storeName, state) {
  try {
    sessionStorage.setItem(storeName, JSON.stringify(state));
  } catch(e) {
    return false;
  }
  return true;
}

export function loadFromStorage(storeName) {
  let data = null;
  try {
    data = JSON.parse(sessionStorage.getItem(storeName));
  } catch(e) {
    return null;
  }
  return data;
}

export function clearStorage(storeName) {
  try {
    sessionStorage.clear();
  } catch(e) {
    return false;
  }
  return true;
}

export function requestApi(uri, data) {
  return request.post(uri)
    .send(data)
    .set("Accept", "application/json");
}

export function loadWording(grade) {
  switch(grade) {
    case "S":
      return WordingS;
    case "H":
      return WordingH;
    default:
      return void 0;
  }
}
