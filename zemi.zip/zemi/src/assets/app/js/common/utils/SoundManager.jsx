import EventEmitter from "events";
import Howler from "howler";
import Sound from "common/utils/Sound";


const EVENTS = {
  END: "end"
};


function loadPromise(src, basepath = null) {
  return new Promise((resolve, reject) => {
    let loadSrc = basepath ? basepath + src : src;
    let sound = new Howler.Howl({
      src: loadSrc,
      autoplay: false,
      loop: false,
      preload: false
    });
    sound.on("load", (e) => {
      resolve({src, sound});
    });
    sound.on("loaderror", (e) => {
      resolve({src, sound: null});
    });
    sound.load();
  });
}

function localPromise(src, sound) {
  if(sound.state() === "loaded") {
    return new Promise((resolve) => {
      resolve({src, sound});
    });
  } else {
    return new Promise((resolve) => {
      sound.on("load", (e) => {
        resolve({src, sound});
      });
    });
  }
}

let howlIdx = {};


/**
 * SoundManagerクラス
 */
class SoundManager {


  //----------------------------------------------------------------------------------------------------
  /// constructor
  constructor() {
    howlIdx = {};
  }


  //----------------------------------------------------------------------------------------------------
  /// public
  /**
   * 音声ファイルのロード・プリロード用メソッド
   * @param {(string|string[])} src - 1つのファイル又は、配列で複数のファイルを指定
   * @param {string=} basepath - srcで指定されているファイルのベースパスを指定
   * @return {Promise} Promiseを返します。
   * @example
   * // 1 - 単純ロード
   * SoundManager.load("./assets/app/media/bgm01.mp3");
   * // 2 - ベースパス指定ロード
   * SoundManager.load("bgm01.mp3", "./assets/app/media/");
   * // 3 - ベースパス指定して、複数の音声ファイルをロード（★ パスが未定のため、basepath指定していただきたいと考えております）
   * SoundManager.load(["bgm01.mp3", "bgm02.mp3"], "./assets/app/media/");
   * // 4 - ベースパス指定して、複数の音声ファイルをロードし、完了時にthen()実行
   * SoundManager.load(["bgm01.mp3", "bgm02.mp3"], "./assets/app/media/").then(function() { console.log("load complete"); });
   */
  load(src = [], basepath = null) {
    if(!Array.isArray(src)) src = [src];
    let promises = src.map((val) => {
      if(howlIdx[val]) {
        return localPromise(val, howlIdx[val]);
      } else {
        return loadPromise(val, basepath);
      }
    });
    return Promise.all(promises)
      .then((vals) => {
        vals.forEach((val) => {
          if(val.sound) howlIdx[val.src] = val.sound;
        });
      });
  }

  /**
   * 音声再生メソッド（プリロードされていない場合は、ロードしてから再生されます）
   * @param {string} src - 再生するファイル名（load時のsrcの部分を利用）
   * @param {number=} volume - 音量（0〜1、デフォルト：1）
   * @param {boolean=} loop - ループ指定（デフォルト：false）
   * @return {Sound} Soundオブジェクトを返します。
   * @example
   * // 1 - 単純再生
   * SoundManager.play("bgm01.mp3");
   * // 2 - 音量とループ指定して再生
   * SoundManager.play("bgm01.mp3", 0.5, true);
   * // 3 - 再生して、sound変数を取得
   * var sound = SoundManager.play("bgm01.mp3");
   */
  play(src, volume = 1, loop = false) {
    let howl = howlIdx[src];
    if(!howl) {
      howl = howlIdx[src] = new Howler.Howl({
        src: src,
        autoplay: false,
        loop: false,
        preload: true
      });
    }
    return new Sound(howl, howl.play(), volume, loop);
  }

  /**
   * 音声再生メソッド（プリロードされていない場合は、ロードしてから再生されます）
   * @param {string} src - 再生するファイル名（load時のsrcの部分を利用）
   * @param {number=} volume - 音量（0〜1、デフォルト：1）
   * @return {Promise} Promiseを返します。
   * @example
   * // 1 - 単純再生（play()と差なし）
   * SoundManager.playPromise("bgm01.mp3");
   * // 2 - 音量とループ指定して再生（play()と差なし）
   * SoundManager.playPromise("bgm01.mp3", 0.5, true);
   * // 3 - 再生し、再生終了時に then()を実行
   * SoundManager.playPromise("bgm01.mp3").then(function() { console.log("play complete"); });
   * // 4 - se1 → se2 → se1 の順番で再生
   * SoundManager.playPromise("se1.mp3")
   * .then(function() { return SoundManager.playPromise("se2.mp3"); })
   * .then(function() { return SoundManager.playPromise("se1.mp3"); });
   */
  playPromise(src, volume = 1) {
    return this.load(src).then(() => {
      return new Promise((resolve, reject) => {
        let howl = howlIdx[src];
        if(!howl) {
          resolve(null);
          return;
        }
        let sound = new Sound(howl, howl.play(), volume);
        howl.once("end", () => {
          resolve(sound);
        });
      });
    });
  }

  /**
   * すべての音声を停止用メソッド
   * @example
   * SoundManager.stopAll();
   */
  stopAll() {
    _.forEach(howlIdx, (howl, key) => {
      howl.stop();
    });
  }

  /**
   * 音声ファイルをアンロード用メソッド
   * @param {(string|string[])} src - 1つのファイル又は、配列で複数のファイルを指定
   * @example
   * SoundManager.unload("bgm01.mp3");
   * SoundManager.unload(["bgm01.mp3", "bgm02.mp3"]);
   */
  unload(src = []) {
    if(!Array.isArray(src)) src = [src];
    src.forEach((val) => {
      if(howlIdx[val]) {
        howlIdx[val].unload();
        delete howlIdx[val];
      }
    });
  }

  /**
   * すべての音声ファイルをアンロード用メソッド
   * @example
   * SoundManager.unloadAll();
   */
  unloadAll() {
    Howler.Howler.unload();
    howlIdx = {};
  }


  //----------------------------------------------------------------------------------------------------
  /// setter / getter
  /**
   * 音量（0〜1）
   * @member {number}
   * @example
   * // volume指定
   * SoundManager.volume = 0.5;
   * // volume取得
   * console.log(SoundManager.volume);
   */
  set volume(val) {
    Howler.Howler.volume(Math.max(0, Math.min(1, val)));
  }

  get volume() {
    return Howler.Howler.volume();
  }

  //----------------------------------------------------------------------------------------------------
}


export default SoundManager;
