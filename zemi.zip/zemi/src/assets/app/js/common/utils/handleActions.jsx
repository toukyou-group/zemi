import {handleAction} from 'redux-actions';
import reduceReducers from 'reduce-reducers';

export default function handleActions(handlers, defaultState) {
  let reducers = [];
  for(let type in handlers) {
    let arrHandles = handlers[type];
    if(!Array.isArray(arrHandles)) arrHandles = [arrHandles];
    for(let handler of arrHandles) {
      reducers.push(handleAction(type, handler));
    }
  }
  const reducer = reduceReducers(...reducers);

  return (state = defaultState, action = null) => reducer(state, action);
}
