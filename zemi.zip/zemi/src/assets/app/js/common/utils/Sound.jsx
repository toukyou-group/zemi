import EventEmitter from "events";


const p = {
  howl: null,
  id: null
};


/**
 * Soundクラス
 * @extends EventEmitter
 * @fires Sound#end
 */
class Sound extends EventEmitter {


  //----------------------------------------------------------------------------------------------------
  /// constructor
  constructor(howl, id, volume = 1, loop = false) {
    super();

    p.howl = howl;
    p.id = id;
    this.volume = volume;
    this.loop = loop;
  }


  //----------------------------------------------------------------------------------------------------
  /// public
  /**
   * 音声再生メソッド
   * @example
   * var sound = SoundManager.play("bgm01.mp3");
   * sound.stop();
   * sound.play();
   */
  play() {
    p.howl.play(p.id);
  }

  /**
   * 音声停止メソッド（positionが最初に戻る）
   * @example
   * var sound = SoundManager.play("bgm01.mp3");
   * sound.stop();
   * sound.play();
   */
  stop() {
    p.howl.stop(p.id);
  }

  /**
   * 音声一時停止メソッド（positionを維持）
   * @example
   * var sound = SoundManager.play("bgm01.mp3");
   * sound.pause();
   * sound.play();
   */
  pause() {
    p.howl.pause(p.id);
  }


  //----------------------------------------------------------------------------------------------------
  /// setter / getter
  /**
   * 音量（0〜1）
   * @member {number}
   * @example
   * var sound = SoundManager.play("bgm01.mp3");
   * sound.volume = 0.5;
   * console.log(sound.volume);
   */
  set volume(val) {
    p.howl.volume(Math.max(0, Math.min(1, val)), p.id);
  }

  get volume() {
    return p.howl.volume(p.id);
  }

  /**
   * 再生位置（秒数）
   * @member {number}
   * @example
   * var sound = SoundManager.play("bgm01.mp3");
   * sound.position = 1.3;
   * console.log(sound.position);
   */
  set position(val) {
    p.howl.seek(Math.max(0, Math.min(this.duration, val)), p.id);
  }

  get position() {
    return p.howl.seek(p.id);
  }

  /**
   * ループ設定
   * @member {boolean}
   * @example
   * var sound = SoundManager.play("bgm01.mp3", 1, true);
   * sound.loop = false;
   * console.log(sound.loop);
   */
  set loop(val) {
    p.howl.loop(val === true, p.id);
  }

  get loop() {
    return p.howl.loop(p.id);
  }

  /**
   * 音声のduration（秒数）
   * @member {number}
   * @readonly
   * @example
   * var sound = SoundManager.play("bgm01.mp3");
   * console.log(sound.duration);
   */
  get duration() {
    return p.howl.duration(p.id);
  }

  //----------------------------------------------------------------------------------------------------
  /**
   * 音声再生終了時イベント
   * @event Sound#end
   * @type {object}
   */
  //----------------------------------------------------------------------------------------------------
}


export default Sound;
