import {Enum} from "common/utils";

let constants = {
  LearningSettingTitle: {
    label: "学習設定をしよう"
  },
  LearningScheduleTitle: {
    label: "取込時間を設定しよう"
  }
};

export default Enum.define("WordingS", {constants});

