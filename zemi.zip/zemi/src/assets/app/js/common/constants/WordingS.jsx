import {Enum} from "common/utils";

let constants = {
  LearningSettingTitle: {
    label: "がくしゅうせっていをしよう"
  },
  LearningScheduleTitle: {
    label: "とりこみじかんをせっていしよう"
  }
};

export default Enum.define("WordingS", {constants});
