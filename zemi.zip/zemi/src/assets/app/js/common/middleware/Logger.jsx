const Logger = (config = {}) => {

  let {pageName} = config;

  let ayncSendLog = (log) => {
    window.console.log(...log);
  };

  // TOOD configにより、アクションログ送信するかどうかを決める
  let needSend = action => {
    return true;
  };

  return store => next => action => {

    if(needSend(action)) {
      let log = ["page: " + pageName + ",action:", action];
      ayncSendLog(log);
    }

    return next(action);
  };
};

export default Logger;
