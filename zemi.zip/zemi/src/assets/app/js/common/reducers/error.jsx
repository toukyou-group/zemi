import handleActions from '../utils/handleActions';
import {ACTIONS} from '../constants/Constants';


const initialState = {
  display: false,
  code: "",
  message: ""
};


const showErrorDialog = {
  next(state, action) {
    return {
      display: true,
      code: action.payload.code,
      message: action.payload.message
    };
  }
};

const closeErrorDialog = {
  next(state, action) {
    return _.merge({}, state, {display: false});
  }
};


export default handleActions({
  [ACTIONS.SHOW_ERROR_DIALOG]: showErrorDialog,
  [ACTIONS.CLOSE_ERROR_DIALOG]: closeErrorDialog
}, initialState);
