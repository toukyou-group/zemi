import {Enum} from "common/utils";

export default Enum.define("SchoolStatus", {
  constants: {
    UnSelected: {
      code: 1,
      value: "未選択"
    },
    Harry: {
      code: 2,
      value: "忙しい"
    },
    Normal: {
      code: 3,
      value: "ふつう"
    },
    None: {
      code: 4,
      value: "ない"
    }
  }
});
