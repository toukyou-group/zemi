import {Enum} from "common/utils";

export default Enum.define("LectureExercisesKbn", {
  constants: {
    None: {
      code: 0,
      value: "未選択"
    },
    Lecture: {
      code: 1,
      value: "講義"
    },
    Exercises: {
      code: 2,
      value: "演習"
    }
  }
});
