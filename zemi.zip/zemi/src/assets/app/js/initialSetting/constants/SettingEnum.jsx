import {Enum} from "common/utils";

export default Enum.define("SettingEnum", {
  constants: {
    NicknameSetting: {
      labelString: "ニックネーム",
      path: "nickname"
    },
    TargetSetting: {
      labelString: "目標設定",
      path: "target"
    },
    LearningSetting: {
      labelString: "学習設定",
      path: "learning"
    },
    LearningSchedule: {
      labelString: "取込時間",
      path: "schdule"
    }
  }
}, "step");
