import React, {Component, PropTypes} from "react";
import {connect} from 'react-redux';

import Header from "../components/learningSchedule/Header";
import Schedule from "../components/learningSchedule/Schedule";
import Footer from "../components/learningSchedule/Footer";


import {bindActionCreators} from 'redux';
import * as Actions from '../actions';

import {loadWording} from "common/utils";

export class LearningScheduleComponent extends Component {

  render() {
    return (
      <div style={{"background": "url(./assets/app/imgs/initialsetting/B_bg_09~iphone@2x.png)", "backgroundSize": "cover", "paddingTop": "20px", "height": "700px"}}>
        <div style={{"paddingLeft": "20px", "paddingRight": "20px"}} >
          <Header wording={this.props.wording} />
          <Schedule />
          <Footer
            homework={this.props.homework}
            bukatu={this.props.bukatu}
            onTapBack={this.props.actions.syncShowLearningSetting}
            onChangeBukatu={this.props.actions.syncChangeBukatuState}
            onChangeHomework={this.props.actions.syncChangeHomeworkState}
            onTapRegister={this.props.actions.asyncRegisterInitialSetting}
          />
        </div>
      </div>
    );
  }

}

LearningScheduleComponent.propTypes = {
  actions: PropTypes.object.isRequired,
  bukatu: PropTypes.number.isRequired,
  homework: PropTypes.number.isRequired,
  wording: PropTypes.func.isRequired
};

function mapStateToProps(state) {
  // wording設定
  let grade = "H";
  let wording = loadWording(grade);

  return _.merge({}, state.entity.challengeTimeSetting, {wording});
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(LearningScheduleComponent);

