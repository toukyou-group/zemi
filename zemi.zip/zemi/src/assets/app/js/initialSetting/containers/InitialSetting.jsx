import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import * as Actions from "../actions";
import {connect} from 'react-redux';

import ErrorDialog from "common/components/ErrorDialog";
import Header from "../components/Header";
import LearningSettingContainer from "./LearningSetting";
import LearningScheduleContainer from "./LearningSchedule";
import RegisterCompleteContainer from "./RegisterComplete";
import SettingEnum from "../constants/SettingEnum";

export class InitialSettingComponent extends Component {

  componentDidMount() {
    this.props.actions.syncShowLearningSetting();
  }

  render() {
    return (
      <div style={{"background": "url(./assets/app/imgs/initialsetting/A_A_bg_00~ipad@2x.png)", "backgroundSize": "cover"}}>
        <div style={{width: "1024px", height: "800px", "marginLeft": "auto", "marginRight": "auto"}}>
          <div className="container-fluid">
            <ErrorDialog error={this.props.error} closeAction={this.props.actions.closeErrorDialog}/>
            <Header pagePath={this.props.pagePath}/>

            {this.props.children}
          </div>
        </div>
      </div>
    );
  }
}

InitialSettingComponent.propTypes = {
  children: PropTypes.node,
  error: PropTypes.object.isRequired,
  pagePath: PropTypes.string.isRequired,
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state) {

  let pagePath = state.routing.locationBeforeTransitions.pathname.replace(/^\//, "").replace(/\/.*$/, "");
  return {
    error: state.error,
    pagePath
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(InitialSettingComponent);
