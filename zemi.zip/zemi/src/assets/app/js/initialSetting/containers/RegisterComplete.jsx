import React, {Component, PropTypes} from "react";
import {connect} from 'react-redux';

import {bindActionCreators} from 'redux';
import * as Actions from '../actions';

export class RegisterCompleteComponent extends Component {

  render() {
    return (
      <div style={{"background": "url(./assets/app/imgs/initialsetting/B_bg_09~iphone@2x.png)", "backgroundSize": "cover", "paddingTop": "20px", "height": "700px"}}>
        <div style={{"paddingLeft": "20px", "paddingRight": "20px", "marginTop": "10px"}} >
          登録完了！
        </div>
      </div>
    );
  }

}

RegisterCompleteComponent.propTypes = {
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state) {
  return {
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(RegisterCompleteComponent);
