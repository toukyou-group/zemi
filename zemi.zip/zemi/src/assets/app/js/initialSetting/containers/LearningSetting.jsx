import React, {Component, PropTypes} from "react";
import {connect} from 'react-redux';

import Header from "../components/learningSetting/Header";
import Table from "../components/learningSetting/Table";
import Footer from "../components/learningSetting/Footer";

import {bindActionCreators} from 'redux';
import * as Actions from '../actions';

import {loadWording} from "common/utils";
import LectureExercisesKbn from "../constants/LectureExercisesKbn";

export class LearningSettingComponent extends Component {

  componentDidMount() {
    if(!this.props.initialLoaded) {
      this.props.actions.asyncGetLearningSetting();
    }
  }

  render() {
    return (
      <div id="L1_container">
        <div className="content">
          <Header
            grade={this.props.grade}
            wording={this.props.wording}
            onTapHelp={this.props.actions.syncShowLearningSettingHelp}
          />
          <Table
            learningSetting={this.props.learningSetting}
            codeInformation={this.props.codeInformation}
            onChangeSelectLectureExercisesKubun={this.props.actions.syncChangeSelectLectureExercisesKubun}
          />
          <Footer
            onTapBack={this.props.actions.syncShowTargetSetting}
            nextStepDisabled={this.props.nextStepDisabled}
            onTapNext={this.props.actions.checkLearningSetting}
          />
        </div>
        {/*「学習設定とは」のオーバーレイ画面はここで表示*/}
        {this.props.children}
      </div>
    );
  }

}

LearningSettingComponent.propTypes = {
  initialLoaded: PropTypes.bool.isRequired,
  learningSetting: PropTypes.array.isRequired,
  codeInformation: PropTypes.array.isRequired,
  nextStepDisabled: PropTypes.bool.isRequired,
  grade: PropTypes.string.isRequired,
  wording: PropTypes.func.isRequired,
  actions: PropTypes.object.isRequired,
  children: PropTypes.node
};

function mapStateToProps(state, ownProps) {
  let nextStepDisabled = state.entity.learningSetting.length == 0;
  for(let i in state.entity.learningSetting) {
    if(state.entity.learningSetting[i].lectureExercisesKubun == LectureExercisesKbn.None.code) {
      nextStepDisabled = true;
      break;
    }
  }

  let codeInformation = [];
  let arr = state.entity.screenDisplayCodeMasterInformation.filter(obj => obj.displayClass == "0000000002");
  if(arr.length > 0) {
    codeInformation = arr[0].codeInformation;
  }

  let learningSetting = state.entity.learningSetting.map(subject => {

    let displayOrder = 0;
    for(let i in state.entity.learningSubjectMaster) {
      if(subject.subjectCode == state.entity.learningSubjectMaster[i].subjectCode) {
        displayOrder = state.entity.learningSubjectMaster[i].displayOrder;
        break;
      }
    }

    return _.merge({}, subject, {displayOrder});
  });

  // wording設定
  let grade = "H";
  let wording = loadWording(grade);

  return {
    initialLoaded: state.learningSetting.loaded,
    learningSetting,
    nextStepDisabled,
    codeInformation,
    grade,
    wording
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(LearningSettingComponent);

