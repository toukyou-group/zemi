import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import * as Actions from "../actions";
import {connect} from 'react-redux';

export class LearningSettingHelpComponent extends Component {
  render() {
    return (
      <div style={{"zIndex": "2", "position": "absolute", "background": "#000000", "opacity": "0.5", "top": "0", "left": "0", "width": "100%", "height": "100%"}}>
        <div style={{"fontSize": "48px", "marginLeft": "auto", "marginRight": "auto", "width": "60%", "marginTop": "30px", "color": "#FFFFFF"}}>
        学習設定とは<br/>。。。。です
          <div style={{color: "#00FFFF", "fontSize": "24px", "marginTop": "50px", "textAlign": "center"}}>
            <button onClick={this.props.actions.syncShowLearningSetting}><span>閉じる</span></button>
          </div>
        </div>
      </div>
    );
  }
}

LearningSettingHelpComponent.propTypes = {
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state, ownProps) {
  return {
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(LearningSettingHelpComponent);

