import React, {Component, PropTypes} from "react";
import {GradeFilter, GradeNode} from "common/components";

export default class Header extends Component {

  render() {
    return (
      <div className="row">
        <div className="col-sm-2">
          <img src="./assets/app/imgs/initialsetting/B_CK_img_01~ipad@2x.png" style={{"width": "117px", "height": "104px"}}/>
        </div>

        <div className="col-sm-8 text-center">
          <div style={{"fontSize": "28px"}}>
          { /*ワーディング*/ this.props.wording.LearningSettingTitle.label}
          </div>
          { /*学齢により画面のり替え表示*/ }
          <GradeFilter grade={this.props.grade} >
            <GradeNode renderGrades="CH" >
              <div style={{"marginTop": "10px", "color": "#a29b9b"}}>
                キミに最適な「学習カリキュラム」を作成するため、各教科に必要な設定をしよう。
              </div>
            </GradeNode>
            <GradeNode renderGrades="S" >
              <div style={{"marginTop": "10px", "color": "#a29b9b"}}>
                きみにさいてきな「がくしゅうカリキュラム」をさくせいするため、かくきょうかにひつようなせっていをしよう。
              </div>
            </GradeNode>
          </GradeFilter>
          <div style={{"marginTop": "10px", "color": "#FF0000"}}>
            ※設定内容は「教室」で、いつでも変更できます。
          </div>
        </div>
        <div className="col-sm-2">
          <a href="javascript:void(0)" onClick={this.props.onTapHelp}>
            <img src="./assets/app/imgs/initialsetting/B_btn_03_nor~ipad@2x.png" style={{"width": "136px", "height": "32px"}}/>
          </a>
        </div>
      </div>
    );
  }

}

Header.propTypes = {
  grade: PropTypes.string.isRequired,
  wording: PropTypes.func.isRequired,
  onTapHelp: PropTypes.func.isRequired
};
