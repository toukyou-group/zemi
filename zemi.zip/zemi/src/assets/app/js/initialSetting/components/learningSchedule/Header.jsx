import React, {Component, PropTypes} from "react";

export default class Header extends Component {

  render() {
    return (
      <div className="row">
        <div className="col-sm-2">
          <img src="./assets/app/imgs/initialsetting/B_CK_img_01~ipad@2x.png" style={{"width": "117px", "height": "104px"}}/>
        </div>

        <div className="col-sm-7 text-center">
          <div style={{"fontSize": "28px"}}>
            {this.props.wording.LearningScheduleTitle.label}
          </div>
          <div style={{"marginTop": "10px", "color": "#a29b9b"}}>
            1234567890は1週間で２時間必要だよ。
          </div>
          <div style={{"marginTop": "5px", "color": "#a29b9b"}}>
            あと0時間設定しよう。
          </div>
          <div style={{"marginTop": "5px", "color": "#FF0000"}}>
            ※登録時間は「カレンダー」でいつでも変更できます。
          </div>
        </div>
        <div className="col-sm-3 text-right">
          <a href="javascript:void(0)">
            <img src="./assets/app/imgs/initialsetting/B_btn_07_nor~ipad@2x.png" style={{"width": "104px", "height": "32px"}}/>
          </a>
          <div style={{"marginTop": "10px"}}>
          <a href="javascript:void(0)">
            <img src="./assets/app/imgs/initialsetting/B_btn_08_nor~ipad@2x.png" style={{"width": "80px", "height": "80px"}}/>
          </a>
          <a href="javascript:void(0)">
            <img src="./assets/app/imgs/initialsetting/B_btn_10_nor~ipad@2x.png" style={{"width": "80px", "height": "80px"}}/>
          </a>
          </div>
        </div>
      </div>
    );
  }

}

Header.propTypes = {
  wording: PropTypes.func.isRequired
};

