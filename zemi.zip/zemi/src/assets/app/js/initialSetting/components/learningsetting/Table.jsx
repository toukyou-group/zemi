import React, {Component, PropTypes} from "react";

import List from "./List";

export default class Table extends Component {

  render() {
    return (
        <div style={{"marginTop": "28px", "height": "410px"}}>
          <div style={{"color": "#a29b9b", "height": "30px"}}>
            <div style={{"width": "268px", "float": "left"}}>
              教科
            </div>
            <div style={{"width": "353px", "float": "left", "paddingLeft": "15px"}}>
              講義/演習
            </div>
            <div style={{"width": "320px", "float": "left", "clear": "right"}}>
              &nbsp;
            </div>
          </div>
          <div>
            {
              this.props.learningSetting.sort((a, b) => {
                return a.displayOrder - b.displayOrder;
              }).map(subject => {
                return (
                  <List
                    key={subject.subjectCode}
                    subject={subject}
                    codeInformation={this.props.codeInformation}
                    onChangeSelectLectureExercisesKubun={this.props.onChangeSelectLectureExercisesKubun}
                  />
                );
              })
            }
          </div>
        </div>
    );
  }

}

Table.propTypes = {
  learningSetting: PropTypes.array.isRequired,
  codeInformation: PropTypes.array.isRequired,
  onChangeSelectLectureExercisesKubun: PropTypes.func.isRequired
};

