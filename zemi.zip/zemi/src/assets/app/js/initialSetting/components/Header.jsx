import React, {Component, PropTypes} from "react";

import SettingEnum from "../constants/SettingEnum";

export default class Header extends Component {
  render() {
    let selectedStyle = {
      color: "#2394fb",
      textAlign: "center",
      border: "1px solid #FFFFFF",
      background: "#FFFFFF"
    };
    let unselectStyle = {
      border: "1px solid #FFFFFF",
      textAlign: "center",
      color: "#FFFFFF",
    };
    return (
      <div>
        <div className="row" style={{"width": "600px", "marginLeft": "auto", "marginRight": "auto", "paddingTop": "15px", "paddingBottom": "15px"}}>
        {
          SettingEnum.values().map(setting => {
            return (
              <div key={setting.path} className="col-sm-3" style={setting.path == this.props.pagePath ? selectedStyle : unselectStyle}>
                {setting.labelString}
              </div>
            );
          })
        }
        </div>
      </div>
    );
  }
}

Header.propTypes = {
  pagePath: PropTypes.string.isRequired
};
