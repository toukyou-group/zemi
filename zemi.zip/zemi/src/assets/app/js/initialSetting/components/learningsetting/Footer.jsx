import React, {Component, PropTypes} from "react";

export default class Footer extends Component {

  render() {
    return (
        <div style={{"marginTop": "10px"}}>
          <div className="text-center" style={{"color": "#a29b9b", "paddingTop": "5px"}}>
            ※受講していない、または、ハイブリッドスタイルを選択していない教科についても仮入力をお願いいたします。
          </div>
          <div className="row" style={{"marginTop": "30px"}}>
            <div className="col-sm-6" style={{"paddingLeft": "30px"}}>
              <a href="javascript:void(0)" onClick={this.props.onTapBack}>
                <img src="./assets/app/imgs/initialsetting/common_btn_prev_nor~ipad@2x.png" style={{"widht": "120px", "height": "48px"}}/>
              </a>
            </div>
            <div className="col-sm-6 text-right" style={{"paddingRight": "30px"}}>
              <a href="javascript:void(0)" onClick={this.props.nextStepDisabled ? null : this.props.onTapNext}>
                <img src={this.props.nextStepDisabled ? "./assets/app/imgs/initialsetting/common_btn_next_dis~ipad@2x.png" : "./assets/app/imgs/initialsetting/common_btn_next_nor~ipad@2x.png"} style={{"widht": "120px", "height": "48px"}}/>
              </a>
            </div>
          </div>
        </div>
    );
  }

}

Footer.propTypes = {
  nextStepDisabled: PropTypes.bool.isRequired,
  onTapBack: PropTypes.func.isRequired,
  onTapNext: PropTypes.func.isRequired
};

