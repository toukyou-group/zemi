import React, {Component, PropTypes} from "react";

export default class StatusSelector extends Component {

  render() {
    let selectedStyle = {
      display: "inline-block",
      width: "60px",
      color: "#FFFFFF",
      textAlign: "center",
      border: "1px solid #1E90FF",
      background: "#1E90FF"
    };
    let unselectStyle = {
      display: "inline-block",
      width: "60px",
      border: "1px solid #1E90FF",
      textAlign: "center",
      color: "#1E90FF",
    };

    return (
      <div className={this.props.className} style={this.props.style}>
        <span style={{marginRight: "10px"}}>{this.props.title}</span>
        {
          this.props.options.values().map(option => {
            return (
              <a
                href="javascript:void(0)"
                onClick={() => {this.props.onChange(option.code);}}
                style={this.props.value == option.code ? selectedStyle : unselectStyle}
                key={option.code}
              >
                {option.value}
              </a>
            );
          })
        }
      </div>
    );
  }
}

StatusSelector.propTypes = {
  title: PropTypes.string.isRequired,
  className: PropTypes.string,
  style: PropTypes.object,
  value: PropTypes.number,
  options: PropTypes.func.isRequired,
  onChange: PropTypes.func
};

