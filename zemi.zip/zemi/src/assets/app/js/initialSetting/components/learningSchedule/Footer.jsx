import React, {Component, PropTypes} from "react";
import StatusSelector from "./StatusSelector";
import SchoolStatus from "../../constants/SchoolStatus";

export default class Footer extends Component {

  render() {
    return (
      <div style={{"marginTop": "30px"}}>
        <div className="text-left" style={{"paddingTop": "5px"}}>
          学校の宿題や部活の状況を登録しよう!
        </div>
        <StatusSelector
          className="col-sm-6 text-left"
          style={{"paddingLeft": "30px"}}
          title="部活"
          value={this.props.bukatu}
          onChange={this.props.onChangeBukatu}
          options={SchoolStatus}
        />
        <StatusSelector
          className="col-sm-6 text-right"
          style={{"paddingRight": "30px"}}
          title="宿題"
          value={this.props.homework}
          onChange={this.props.onChangeHomework}
          options={SchoolStatus}
        />
        <div className="row" style={{"marginTop": "40px"}}>
          <div className="col-sm-6" style={{"paddingLeft": "30px"}}>
            <a href="javascript:void(0)" onClick={this.props.onTapBack}>
              <img src="./assets/app/imgs/initialsetting/common_btn_prev_nor~ipad@2x.png" style={{"widht": "120px", "height": "48px"}}/>
            </a>
          </div>
          <div className="col-sm-6 text-right" style={{"paddingRight": "30px"}}>
            <a href="javascript:void(0)" onClick={this.props.onTapRegister}>
              <img src="./assets/app/imgs/initialsetting/common_btn_touroku_nor~ipad@2x.png" style={{"widht": "120px", "height": "48px"}}/>
            </a>
          </div>
        </div>
      </div>
    );
  }
}

Footer.propTypes = {
  bukatu: PropTypes.number.isRequired,
  homework: PropTypes.number.isRequired,
  onChangeBukatu: PropTypes.func.isRequired,
  onChangeHomework: PropTypes.func.isRequired,
  onTapBack: PropTypes.func.isRequired,
  onTapRegister: PropTypes.func.isRequired
};
