import React, {Component, PropTypes} from "react";

import {PullDown} from "../../../common/components";

export default class List extends Component {

  render() {
    // TODO 共通で使うなら、リソースをcommon配下に持って行って、Map定義も共通化する
    const iconMap = {
      "E": "./assets/app/imgs/initialsetting/common_icon_001~ipad@2x.png",
      "M": "./assets/app/imgs/initialsetting/common_icon_002~ipad@2x.png",
      "J": "./assets/app/imgs/initialsetting/common_icon_003~ipad@2x.png",
      "R": "./assets/app/imgs/initialsetting/common_icon_004~ipad@2x.png",
      "S": "./assets/app/imgs/initialsetting/common_icon_005~ipad@2x.png"
    };

    return (
      <div className="list">
        <div className="item1">
          <img src={iconMap[this.props.subject.subjectCode]} style={{"width": "36px", "height": "36px"}}/>
          <span style={{"marginLeft": "20px"}}>{this.props.subject.subjectName}</span>
          <span style={{"fontSize": "12px", "color": "#FF0000"}}>(必須)</span>
        </div>
        <div className="item2">
          <PullDown value={this.props.subject.lectureExercisesKubun}
            onChange={(e) => {this.props.onChangeSelectLectureExercisesKubun(this.props.subject.subjectCode, e.target.value);}}
            options={this.props.codeInformation}
            className="select"
          />
        </div>
        <div className="item3">
          &nbsp;
        </div>
      </div>
    );
  }
}

List.propTypes = {
  subject: PropTypes.object.isRequired,
  codeInformation: PropTypes.array.isRequired,
  onChangeSelectLectureExercisesKubun: PropTypes.func.isRequired
};

