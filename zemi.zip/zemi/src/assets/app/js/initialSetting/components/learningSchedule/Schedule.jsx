import React, {Component, PropTypes} from "react";


export default class Schedule extends Component {

  render() {
    return (
        <div style={{"marginTop": "28px", "height": "360px"}}>

        </div>
    );
  }
}
