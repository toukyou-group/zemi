import {requestApi} from "../../common/utils";
import {showErrorDialog} from "common/actions/error";

import * as sync from "./sync";
import * as formater from "./formater";
import * as validator from "./validator";

export const asyncGetLearningSetting = () => {
  return (dispatch, getState) => {
    let learningSubjectMaster = {};
    requestApi("/api/getLearningSubjectMaster").then(res => {
      learningSubjectMaster = res.result.learningSubjectMaster;
      return requestApi("/api/getLearningSetting");
    }).then(res => {
      _.merge(res.result, {learningSubjectMaster});
      dispatch(sync.syncGetLearningSetting(res));
      dispatch(sync.syncLearningSettingLoaded());
    }).catch((err) => {
      // 共通エラーアクションをdispatchする
      dispatch(showErrorDialog(err));
    });
  };
};

export const asyncRegisterInitialSetting = () => {
  return (dispatch, getState) => {
    return requestApi("/api/registerInitialSetting", formater.requestParamCreator(getState)).then(res => {
      // 画面遷移する（一旦は仮実装）
      dispatch(sync.syncShowComplete());
    }).catch(err => {
      // 共通エラーアクションをdispatchする
      dispatch(showErrorDialog(err));
    });
  };
};

export const checkLearningSetting = () => {
  return (dispatch, getState) => {
    let result = validator.validateLearningSetting(getState);
    if(result){
      dispatch(sync.syncShowLearningSchedule());
    }else{
      let err = {'code': 'TEST0001', 'message': '全て講義を選択することはできません'};
      dispatch(showErrorDialog(err));
    }
  };
};
