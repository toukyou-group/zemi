import LectureExercisesKbn from "../constants/LectureExercisesKbn";

export function validateLearningSetting(getState) {

  let state = getState();
  let learningSetting = state.entity.learningSetting;
  for(let i in learningSetting) {
    if(learningSetting[i].lectureExercisesKubun != LectureExercisesKbn.Lecture.code){
      return true;
    }
  }
  return false;
}

