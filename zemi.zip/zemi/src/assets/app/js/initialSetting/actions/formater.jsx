export function requestParamCreator(getState) {

  let state = getState();
  let learningSetting = state.entity.learningSetting;
  let challengeTimeSetting = state.entity.challengeTimeSetting;
  return {
    "jsonrpc": "2.0",
    "id": "unit-test-json-id",
    param: {
      learningSetting,
      challengeTimeSetting
    }
  };
}
