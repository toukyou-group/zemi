import {ACTIONS} from '../constants/Constants';
import {createAction} from 'redux-actions';
import SettingEnum from "../constants/SettingEnum";
import {push} from "react-router-redux";

export const syncGetLearningSetting = createAction(ACTIONS.GET_LEARNING_SETTING, res => { return {result: res.result}; });
export const syncChangeSelectLectureExercisesKubun = createAction(ACTIONS.CHANGE_SELECT_LECTURE_EXERCISES_KUBUN, (subjectCode, selectedValue) => ({subjectCode, selectedValue}));
export const syncLearningSettingLoaded = createAction(ACTIONS.LEARNING_SETTING_LOADED);
export const syncChangeBukatuState = createAction(ACTIONS.CHANGE_BUKATU_STATE, (bukatu) => ({bukatu}));
export const syncChangeHomeworkState = createAction(ACTIONS.CHANGE_HOMEWORK_STATE, (homework) => ({homework}));
export const syncRegisterInitialSetting = createAction(ACTIONS.REGISTER_INITIAL_SETTING, (learningSetting, challengeTimeSetting) => { return {learningSetting, challengeTimeSetting}; });

export const syncShowLearningSetting = () => {
  return push("/" + SettingEnum.LearningSetting.path);
};

export const syncShowLearningSchedule = () => {
  return push("/" + SettingEnum.LearningSchedule.path);
};

export const syncShowTargetSetting = () => {
  return push("/" + SettingEnum.TargetSetting.path);
};

export const syncShowComplete = () => {
  return push("/complete");
};

export const syncShowLearningSettingHelp = () => {
  return push("/" + SettingEnum.LearningSetting.path + "/help");
};

