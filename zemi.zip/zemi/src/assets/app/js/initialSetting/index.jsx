import React from "react";
import {render} from "react-dom";
import {Provider} from "react-redux";

import {getMuiTheme, MuiThemeProvider} from 'material-ui/styles';
import injectTapEventPlugin from 'react-tap-event-plugin';

import configureStore from "./store";
import Root from './containers/InitialSetting';
import LearningSettingContainer from './containers/LearningSetting';
import LearningSettingHelpContainer from "./containers/LearningSettingHelp";
import LearningScheduleContainer from './containers/LearningSchedule';
import RegisterCompleteContainer from "./containers/RegisterComplete";

import SettingEnum from "./constants/SettingEnum";

import {Router, Route, createMemoryHistory} from "react-router";
import {syncHistoryWithStore} from "react-router-redux";

let memoryHistory = createMemoryHistory();
const store = configureStore(memoryHistory);
const history = syncHistoryWithStore(memoryHistory, store);

$(() =>{
  injectTapEventPlugin();
  render(
    <MuiThemeProvider muiTheme={getMuiTheme()}>
      <Provider store={store}>
        <Router history={history} >
          <Route path="/" component={Root}>
            <Route path={SettingEnum.NicknameSetting.path} />
            <Route path={SettingEnum.TargetSetting.path} />
            <Route path={SettingEnum.LearningSetting.path} component={LearningSettingContainer} >
              <Route path="help" component={LearningSettingHelpContainer} />
            </Route>
            <Route path={SettingEnum.LearningSchedule.path} component={LearningScheduleContainer} />
            <Route path="complete" component={RegisterCompleteContainer} />
          </Route>
        </Router>
      </Provider>
    </MuiThemeProvider>,
    document.getElementById("reactroot")
  );
});
