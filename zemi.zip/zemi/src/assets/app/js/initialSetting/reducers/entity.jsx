import handleActions from '../../common/utils/handleActions';
import {ACTIONS} from '../constants/Constants';

const initialState = {
  learningSubjectMaster: [],
  learningSetting: [],
  screenDisplayCodeMasterInformation: [],
  challengeTimeSetting: {
    bukatu: 1,
    homework: 1
  }
};

const getLearningSetting = {
  next(state, action) {
    return _.merge({}, state, action.payload.result);
  }
};

const changeSelectLectureExercisesKubun = {
  next(state, action) {
    let lectureExercisesKubun = action.payload.selectedValue;
    let learningSetting = state.learningSetting.map(subject => {
      if(subject.subjectCode == action.payload.subjectCode) {
        return _.merge({}, subject, {lectureExercisesKubun});
      }
      return subject;
    });
    return _.merge({}, state, {learningSetting});
  }
};

const registerInitialSetting = {
  next(state, action) {
    return _.merge({}, state, action.payload.result);
  }
};

const changeBukatuState = {
  next(state, action) {
    const newState = _.merge({}, state);
    _.merge(newState.challengeTimeSetting, {bukatu: action.payload.bukatu});
    return newState;
  }
};

const changeHomeworkState = {
  next(state, action) {
    const newState = _.merge({}, state);
    _.merge(newState.challengeTimeSetting, {homework: action.payload.homework});
    return newState;
  }
};


export default handleActions({
  [ACTIONS.GET_LEARNING_SETTING]: getLearningSetting,
  [ACTIONS.CHANGE_SELECT_LECTURE_EXERCISES_KUBUN]: changeSelectLectureExercisesKubun,
  [ACTIONS.REGISTER_INITIAL_SETTING]: registerInitialSetting,
  [ACTIONS.CHANGE_BUKATU_STATE]: changeBukatuState,
  [ACTIONS.CHANGE_HOMEWORK_STATE]: changeHomeworkState
}, initialState);
