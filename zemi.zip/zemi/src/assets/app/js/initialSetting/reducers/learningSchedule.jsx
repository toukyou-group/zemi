import handleActions from '../../common/utils/handleActions';
import {ACTIONS} from '../constants/Constants';

const initialState = {
};

export default handleActions({
}, initialState);
