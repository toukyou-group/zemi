import handleActions from '../../common/utils/handleActions';
import {ACTIONS} from '../constants/Constants';

const initialState = {
  loaded: false
};

const initialLoaded = {
  next(state, action) {
    return {loaded: true};
  }
};

export default handleActions({
  [ACTIONS.LEARNING_SETTING_LOADED]: initialLoaded
}, initialState);
