import {combineReducers} from "redux";
import entity from "./entity";
import initialSetting from "./initialSetting";
import learningSetting from "./learningSetting";
import learningSchedule from "./learningSchedule";
import error from "common/reducers/error";
import {routerReducer} from "react-router-redux";

export default combineReducers({
  error,
  entity, // API
  initialSetting, // カテゴリー
  learningSetting, // 画面：学習設定
  learningSchedule, // 画面：取り込み時間設定
  routing: routerReducer // ---Router
});
