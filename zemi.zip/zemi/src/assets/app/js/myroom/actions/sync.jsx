import {ACTIONS} from "../constants/Constants";
import {createAction} from "redux-actions";

export const syncChangeNickname = createAction(ACTIONS.CHANGE_NICKNAME, nickname => { return {nickname}; });
export const syncCloseChangeNicknameDialog = createAction(ACTIONS.CLOSE_CHANGE_NICKNAME_DIALOG);
export const syncOpenChangeNicknameDialog = createAction(ACTIONS.OPEN_CHANGE_NICKNAME_DIALOG);
export const syncLoading = createAction(ACTIONS.LOADING);
export const syncLoadComplete = createAction(ACTIONS.LOAD_COMPLETE);
