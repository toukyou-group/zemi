import * as sync from "./sync";
import {showErrorDialog} from "common/actions/error";
import {requestApi} from "common/utils";

export const asyncChangeNickame = nickname => {
  return (dispatch, getState) => {
    dispatch(sync.syncCloseChangeNicknameDialog());
    dispatch(sync.syncLoading());
    requestApi("/api/change_nickname", {nickname: nickname}).then((res) => {
      dispatch(sync.syncChangeNickname(res.result.nickname));
      // 次のAPIアクセスはPromiseを返す
      return requestApi("/api/change_nickname", {nickname: "[" + nickname + "]"});
    }).then((res) => {
      dispatch(sync.syncChangeNickname(res.result.nickname));

      // ローディングインジケータ閉じるは最後でやる
    }).then(() => {
      dispatch(sync.syncLoadComplete());
    }).catch((err) => {
      dispatch(sync.syncLoadComplete());
      // 共通エラーアクションをdispatchする
      window.console.log(showErrorDialog(err));
      dispatch(showErrorDialog(err));
    });
  };
};
