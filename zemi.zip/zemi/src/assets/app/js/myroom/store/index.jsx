import {createStore, compose, applyMiddleware} from "redux";
import rootReducer from "../reducers";
import Logger from "common/middleware/Logger";
import thunk from "redux-thunk";

let logger = Logger({pageName: "myroom"});

export default function configureStore(preloadedState) {
  return createStore(
    rootReducer,
    preloadedState,
    applyMiddleware(
      thunk,
      logger
    )
  );
}
