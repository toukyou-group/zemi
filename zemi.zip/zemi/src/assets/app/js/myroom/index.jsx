import React from "react";
import {render} from "react-dom";
import {Provider} from "react-redux";

import {getMuiTheme, MuiThemeProvider} from "material-ui/styles";
import injectTapEventPlugin from "react-tap-event-plugin";

import configureStore from "./store";
import App from "./containers/MyRoom";

const store = configureStore();


$(() =>{
  injectTapEventPlugin();
  render(
    <MuiThemeProvider muiTheme={getMuiTheme()}>
      <Provider store={store}>
        <App />
      </Provider>
    </MuiThemeProvider>,
    document.getElementById("reactroot")
  );
});
