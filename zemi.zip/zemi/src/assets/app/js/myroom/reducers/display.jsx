import {ACTIONS} from "../constants/Constants";
import handleActions from "common/utils/handleActions";


const initialState = {
  showNickNameDialog: false,
  showLoading: false
};

const closeChangeNickNameDialog = {
  next(state) {
    const newState = _.merge({}, state);
    newState.showNickNameDialog = false;
    return newState;
  }
};

const openChangeNickNameDialog = {
  next(state) {
    const newState = _.merge({}, state);
    newState.showNickNameDialog = true;
    return newState;
  }
};

const showLoading = {
  next(state) {
    const newState = _.merge({}, state);
    newState.showLoading = true;
    return newState;
  }
};

const hideLoading = {
  next(state) {
    const newState = _.merge({}, state);
    newState.showLoading = false;
    return newState;
  }
};

export default handleActions({
  [ACTIONS.CLOSE_CHANGE_NICKNAME_DIALOG]: closeChangeNickNameDialog,
  [ACTIONS.OPEN_CHANGE_NICKNAME_DIALOG]: openChangeNickNameDialog,
  [ACTIONS.LOADING]: showLoading,
  [ACTIONS.LOAD_COMPLETE]: hideLoading
}, initialState);


