import handleActions from "common/utils/handleActions";
import {ACTIONS} from "../constants/Constants";
import {saveToStorage, loadFromStorage} from "common/utils";

const reducerKey = "myroom.data";

const initialState = loadFromStorage(reducerKey) || {
  nickname: "",
  nextTest: "2016年7月26日(火)〜2016年7月29日(金)"
};


const saveStateHandler = {
  next(state, action) {
    saveToStorage(reducerKey, state);
    return state;
  }
};

const changeNickName = {
  next(state, action) {
    const newState = _.merge({}, state);
    newState.nickname = action.payload.nickname;
    return newState;
  }
};


export default handleActions({
  [ACTIONS.CHANGE_NICKNAME]: [changeNickName, saveStateHandler]
}, initialState);
