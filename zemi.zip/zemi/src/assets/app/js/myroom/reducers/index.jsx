import {combineReducers} from "redux";
import display from "./display";
import data from "./data";

import error from "common/reducers/error";

export default combineReducers({
  data,
  display,
  error
});
