import React, {Component, PropTypes} from "react";
import Title from "../components/Title";
import Header from "../components/Header";
import ChangeNickNameDialog from "../components/ChangeNickNameDialog";
import Footer from "../components/Footer";
import Task from "../components/Task";
import Target from "../components/Target";
import Loading from "../components/Loading";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import * as Actions from "../actions";
import ErrorDialog from "common/components/ErrorDialog";

export class MyRoomComponent extends Component {

  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="container-fluid">
        <ErrorDialog error={this.props.error} closeAction={this.props.actions.closeErrorDialog}/>
        <Title/>
        <Header
          nickname={this.props.data.nickname}
          hdlOpenChangeNicknameDialog={this.props.actions.syncOpenChangeNicknameDialog}
          />
        <ChangeNickNameDialog
          showNickNameDialog={this.props.display.showNickNameDialog}
          nickname={this.props.data.nickname}
          cancelChange={this.props.actions.syncCloseChangeNicknameDialog}
          commitChange={this.props.actions.asyncChangeNickame}/>
        <Task/>
        <Target nextTest={this.props.data.nextTest}/>
        <Footer/>
        <Loading isLoading={this.props.display.showLoading}/>
      </div>
    );
  }
}

MyRoomComponent.propTypes = {
  data: PropTypes.object.isRequired,
  display: PropTypes.object.isRequired,
  error: PropTypes.object.isRequired,
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state) {
  return {
    data: state.data,
    display: state.display,
    error: state.error
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MyRoomComponent);

