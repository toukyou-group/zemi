import React, {Component, PropTypes} from "react";

export default class Target extends Component {

  render() {
    return (
      <div className="row">
        <div className="col-sm-2" style={{"paddingLeft": "20px"}}>
          <img src="./assets/app/imgs/myroom/K_A_img_02~ipad@2x.png"/>
        </div>
        <div className="col-sm-10">
          <div className="row">
            <div className="col-sm-9">
              <div className="row">
                <div className="col-sm-3">
                  <div style={{"color": "grey"}}>次の定期テスト</div>
                  <div style={{"fontSize": "24px"}}>日程</div>
                </div>
                <div className="col-sm-9" style={{"fontSize": "24px"}}>
                  {this.props.nextTest}
                </div>
              </div>
              <div className="row" style={{"marginTop": "10px"}}>
                <div className="col-sm-3">
                  <div style={{"color": "grey"}}>次の定期テスト</div>
                  <div style={{"fontSize": "24px"}}>目標</div>
                </div>
                <div className="col-sm-9" style={{"fontSize": "24px"}}>
                  登録しよう
                </div>
              </div>
            </div>
            <div className="col-sm-3">
              定期テスト対策設定
            </div>
          </div>
          <hr/>
          <div className="row">
            <div className="col-sm-9">
              <div className="row">
                <div className="col-sm-3" style={{"fontSize": "24px"}}>
                  志望校
                </div>
                <div className="col-sm-9">
                  <div className="row">
                    <div className="col-sm-10">XXXXX</div>
                    <div className="col-sm-2" style={{"color": "grey"}}>高校</div>
                  </div>
                  <div className="row">
                    <div className="col-sm-10">XXXXX</div>
                    <div className="col-sm-2" style={{"color": "grey"}}>学科</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-sm-3">
              <div>
                志望校 登録・変更<br/>
                第2志望以降を見る
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Target.propTypes = {
  nextTest: PropTypes.string
};
