import React, {Component} from "react";

export default class Title extends Component {

  render() {
    return (
      <div className="row">
        <div className="col-sm-2 text-left">
          <a href="javascript:void(0);"><img src="./assets/app/imgs/myroom/FP_btn_01~ipad@2x.png"/></a>
        </div>
        <div className="col-sm-8 text-center">
          <span style={{"fontSize": "48px", "fontWeight": "bold"}}>課題提出・目標設定</span>
        </div>
        <div className="col-sm-2 text-right">
          <a href="javascript:void(0);"><img src="./assets/app/imgs/myroom/K_CK_btn_35~ipad@2x.png"/></a>
        </div>
      </div>
    );
  }
}
