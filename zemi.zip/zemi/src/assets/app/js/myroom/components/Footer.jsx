import React, {Component} from "react";

export default class Footer extends Component {
  render() {
    return (
      <div className="text-center">
        <hr/>
        教材の変更・各種お手続きはこちらから&nbsp;
        <a href="javascript:void(0)">各種お手続き</a>
      </div>
    );
  }
}
