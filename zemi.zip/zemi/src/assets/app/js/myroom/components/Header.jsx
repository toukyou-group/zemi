import React, {PropTypes, Component} from "react";


export default class Header extends Component {

  render() {
    return (
      <div className="row" style={{"background": "url(./assets/app/imgs/myroom/G_A_bg_19~ipad@2x.png)", "paddingTop": "20px"}}>
        <div className="col-sm-2">
          <div style={{"fontSize": "28px", "fontWeight": "bold", "paddingTop": "50px", "marginLeft": "30px"}}>{this.props.nickname}</div>
        </div>
        <div className="col-sm-2">
          <div className="text-center">
            <a href="javascript:void(0)" onTouchTap={this.props.hdlOpenChangeNicknameDialog}><img src="./assets/app/imgs/myroom/K_A_btn_03~ipad@2x.png"/></a>
          </div>
          <div className="text-center">
            ニックネーム変更
          </div>
        </div>
        <div className="col-sm-3">
          <div className="row">
            <div className="col-sm-3">
              <img src="./assets/app/imgs/myroom/K_A_icon_01~ipad@2x.png"/>
            </div>
            <div className="col-sm-9" style={{"paddingLeft": "30px"}}>
              <div style={{"color": "grey"}}>これまでに取り込んだ</div>
              <div style={{"fontSize": "28px"}}>レッスン数</div>
              <div className="row">
                <div className="col-sm-6" style={{"fontSize": "28px", "color": "red"}}>
                  4
                </div>
                <div className="col-sm-6" style={{"fontSize": "24px", "color": "grey"}}>
                  レッスン
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-sm-3">
          <div className="row">
            <div className="col-sm-3">
              <img src="./assets/app/imgs/myroom/K_A_icon_02~ipad@2x.png"/>
            </div>
            <div className="col-sm-9" style={{"paddingLeft": "30px"}}>
              <div style={{"color": "grey"}}>今持っている</div>
              <div style={{"fontSize": "28px"}}>努力賞ポイント</div>
              <div className="row">
                <div className="col-sm-6" style={{"fontSize": "28px", "color": "red"}}>
                  0
                </div>
                <div className="col-sm-6" style={{"fontSize": "24px", "color": "grey"}}>
                  PT
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-sm-2">
          <div className="text-center">
            <a href="javascript:void(0)"><img src="./assets/app/imgs/myroom/K_A_btn_04~ipad@2x.png"/></a>
          </div>
        </div>
      </div>
    );
  }
}

Header.propTypes = {
  nickname: PropTypes.string.isRequired,
  hdlOpenChangeNicknameDialog: PropTypes.func.isRequired
};

