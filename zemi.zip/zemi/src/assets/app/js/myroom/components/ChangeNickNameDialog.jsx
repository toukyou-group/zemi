import {connect} from "react-redux";
import React, {PropTypes, Component} from "react";
import Dialog from "material-ui/Dialog";
import FlatButton from "material-ui/FlatButton";

export default class ChangeNickNameDialog extends Component {

  constructor(props) {
    super(props);
    this.nicknameInput = null;
  }

  render() {
    let actions = [
      <FlatButton
        label="キャンセル"
        primary={true}
        onTouchTap={this.props.cancelChange}
        />,
      <FlatButton
        label="変更"
        primary={true}
        onTouchTap={(e) => {this.props.commitChange(this.nicknameInput.value);}}
        />
    ];
    return (
      <Dialog
        title="ニックネーム変更"
        actions={actions}
        modal={true}
        open={this.props.showNickNameDialog}
        >
        <input type="text" ref={(node) => { this.nicknameInput = node; }}/>
      </Dialog>
    );
  }
}

ChangeNickNameDialog.propTypes = {
  showNickNameDialog: PropTypes.bool.isRequired,
  nickname: PropTypes.string.isRequired,
  commitChange: PropTypes.func.isRequired,
  cancelChange: PropTypes.func.isRequired
};
