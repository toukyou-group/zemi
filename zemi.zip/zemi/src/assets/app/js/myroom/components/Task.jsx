import React, {Component} from "react";

export default class Task extends Component {

  render() {
    return (
      <div className="row">
        <div className="col-sm-2" style={{"paddingLeft": "20px"}}>
          <img src="./assets/app/imgs/myroom/K_A_img_01~ipad@2x.png"/>

          <div style={{"color": "grey", "marginTop": "10px", "marginLeft": "10px"}}>
            赤ペンと<br/>
            マークテスト・模試の<br/>
            提出や確認ができるよ。
          </div>
        </div>
        <div className="col-sm-5">
          <a href="javascript:void(0)">
            <img src="./assets/app/imgs/myroom/K_A_btn_05~ipad@2x.png"/>
          </a>
        </div>
        <div className="col-sm-5">
          <a href="javascript:void(0)">
            <img src="./assets/app/imgs/myroom/K_A_btn_06~ipad@2x.png"/>
          </a>
        </div>
      </div>
    );
  }
}
