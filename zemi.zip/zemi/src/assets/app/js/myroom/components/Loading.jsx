import React, {PropTypes, Component} from "react";
import RefreshIndicator from "material-ui/RefreshIndicator";

class Loading extends Component {

  render() {
    if(this.props.isLoading) {
      return (
        <div className="text-center" style={{"position": "absolute", "zIndex": 99, "top": "0", "width": "100%", "height": "100%", "background": "#FFFFFF", "opacity": "0.6"}}>
          <RefreshIndicator
            style={{"display": "inline-block", "position": "relative", "marginTop": "40%"}}
            status="loading"
            size={100}
            loadingColor={"#FF9800"}
            left={0}
            top={0}
            />
        </div>
      );
    }

    return null;
  }
}

Loading.propTypes = {
  isLoading: PropTypes.bool.isRequired
};

export default Loading;
