import React from "react";
import {render} from "react-dom";
import {Provider} from "react-redux";

import {log} from "common/utils";

import {configureStore} from "./store";
import SampleF03, {SampleF03Component} from "./containers/SampleF03";

const store = configureStore();


(($) => {
  $(() => {
    render(
      <Provider store={store}>
        <SampleF03 />
      </Provider>,
      document.getElementById("reactroot")
    );
  });
})(jQuery);
