import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {Provider, connect} from "react-redux";

import {log} from "common/utils";


export class SampleF03Component extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {

  }

  componentDidUpdate() {
    $.material.ripples();
  }

  render() {
    return (
      <div id="F03-CK" className="container">
        <div className="header">
          <a href="javascript:void(0);" className="btn btn-raised back">&lt;ホームへ</a>
          <h1>中１　５月号　教科別のおすすめ</h1>
          <a href="javascript:void(0);" className="btn btn-raised setting">学習設定</a>
          <a href="javascript:void(0);" className="btn btn-raised help">？</a>
          <h2><i className="M">&nbsp;</i>数学</h2>
          <div className="type">
            <div className="type-icon">練習回</div>
            <p>□□□□□□□□□◎□□□□□□□□□◎□□□□□□□□□◎□□□□□□□□□◎</p>
          </div>
          <a href="javascript:void(0);" className="btn btn-raised selfselect">自分で選ぶ</a>
          <a href="javascript:void(0);" className="btn btn-raised graph">達成ブラフ</a>
        </div>
        <div className="subjects">
          <ul>
            <li className="E">
              <div className="subject-name"><i>&nbsp;</i>英語</div>
              <div className="type">講義</div>
            </li>
            <li className="M">
              <div className="subject-name"><i>&nbsp;</i>数学</div>
              <div className="type">練習回</div>
            </li>
            <li className="J">
              <div className="subject-name"><i>&nbsp;</i>国語</div>
              <div className="type">定着回</div>
            </li>
            <li className="R">
              <div className="subject-name"><i>&nbsp;</i>理科</div>
              <div className="type">記述ドリル</div>
            </li>
            <li className="S">
              <div className="subject-name"><i>&nbsp;</i>社会</div>
              <div className="type">ニガテクリア<br />レッスン</div>
            </li>
          </ul>
        </div>
        <a href="javascript:void(0);" className="btn btn-info btn-fab go">取り組む</a>
      </div>
    );
  }
}
SampleF03Component.propTypes = {
  actions: PropTypes.object
};


function mapStateToProps(state, ownProps) {
  return {
  };
}

function mapDispatchToProps(dispatch, ownProps) {
  return {
    actions: bindActionCreators({}, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SampleF03Component);
