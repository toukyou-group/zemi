import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {Provider, connect} from "react-redux";

import {log} from "common/utils";

import Button from "common/components/Button";


export class SampleB09Component extends Component {

  constructor(props) {
    super(props);

    this._btns = [];

    this.btnCLickHdl = this.btnCLickHdl.bind(this);
    this.addBtnClickHdl = this.addBtnClickHdl.bind(this);
    this.removeBtnClickHdl = this.removeBtnClickHdl.bind(this);
    this.changeBtnClickHdl = this.changeBtnClickHdl.bind(this);
  }

  componentDidMount() {

  }

  componentDidUpdate() {
    //$.material.ripples();
  }


  makeBtn(num, label) {
    return <Button tagname="div" href="javascript:void(0);" onClick={this.btnCLickHdl} key={num} className="btn btn-raised">{label}</Button>;
  }

  btnCLickHdl(e) {
    log(e.target.textContent);
  }

  addBtnClickHdl(e) {
    this._btns.push(this.makeBtn(this._btns.length, `btn ${this._btns.length}`));
    this.forceUpdate();
  }

  changeBtnClickHdl(e) {
    this._btns = this._btns.map((btn, num) => {
      return this.makeBtn(num, e.target.textContent);
    });
    this.forceUpdate();
  }

  removeBtnClickHdl(e) {
    this._btns.pop();
    this.forceUpdate();
  }

  renderBtn() {
    return this._btns;
  }

  render() {
    return (
      <div id="B09-C" className="container">
        <div className="modal">
          <div className="modal-inner">
            <h1>学習設定をしよう！</h1>
            <div className="teacher"></div>
            <p className="offer">キミに最適な「学習カリキュラム」を作成するため、各教科に必要な設定をしよう。</p>
            <p className="note">※設定内容は「教室」でいつでも変更できます。</p>
            <table className="subjects">
              <thead>
              <tr>
                <th>教科</th>
                <th>レベル</th>
                <th>講義/演習</th>
              </tr>
              </thead>
              <tbody>
              <tr>
                <td><i className="subject E">&nbsp;</i>英語<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject M">&nbsp;</i>数学<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject J">&nbsp;</i>国語<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject R">&nbsp;</i>理科<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              <tr>
                <td><i className="subject S">&nbsp;</i>社会<span className="note">(必須)</span></td>
                <td>ハイレベル</td>
                <td>講義</td>
              </tr>
              </tbody>
            </table>
            <div className="footer">
              <a href="javascript:void(0);" onClick={this.removeBtnClickHdl} className="btn btn-raised back">&lt;戻る</a>
              {/*<a href="javascript:void(0);" onClick={this.addBtnClickHdl} className="btn btn-raised next">&gt;次へ</a>*/}
              <Button href="javascript:void(0);" onClick={this.addBtnClickHdl} className="btn btn-raised next"><span style={{"color": "#f00"}}>&gt;次へ</span></Button>
            </div>
          </div>
          <ul className="progress-list">
            <li><a href="javascript:void(0);" onClick={this.changeBtnClickHdl} className="btn btn-raised">ニックネーム</a></li>
            <li><a href="javascript:void(0);" onClick={this.changeBtnClickHdl} className="btn btn-raised">目標設定</a></li>
            <li><a href="javascript:void(0);" onClick={this.changeBtnClickHdl} className="btn btn-raised">定期テスト日程</a></li>
            <li><a href="javascript:void(0);" onClick={this.changeBtnClickHdl} className="btn btn-raised btn-primary">学習設定</a></li>
            <li><a href="javascript:void(0);" onClick={this.changeBtnClickHdl} className="btn btn-raised">取り組み時間</a></li>
          </ul>
        </div>
        {this.renderBtn()}
      </div>
    );
  }
}
SampleB09Component.propTypes = {
  actions: PropTypes.object
};


function mapStateToProps(state, ownProps) {
  return {
  };
}

function mapDispatchToProps(dispatch, ownProps) {
  return {
    actions: bindActionCreators({}, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SampleB09Component);
