import React from "react";
import {render} from "react-dom";
import {Provider} from "react-redux";

import {log} from "common/utils";

import {configureStore} from "./store";
import SampleB09, {SampleB09Component} from "./containers/SampleB09";

const store = configureStore();


(($) => {
  $(() => {
    render(
      <Provider store={store}>
        <SampleB09 />
      </Provider>,
      document.getElementById("reactroot")
    );
  });
})(jQuery);
