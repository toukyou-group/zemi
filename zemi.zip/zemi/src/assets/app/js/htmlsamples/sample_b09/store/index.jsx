import {createStore, applyMiddleware} from "redux";
import thunk from "redux-thunk";


export function configureStore(preloadedState) {
  return createStore(
    state => state,
    preloadedState,
    applyMiddleware(
      thunk
    )
  );
}
