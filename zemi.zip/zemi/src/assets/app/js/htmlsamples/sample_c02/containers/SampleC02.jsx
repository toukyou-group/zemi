import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {Provider, connect} from "react-redux";

import {log} from "common/utils";


export class SampleC02Component extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {

  }

  componentDidUpdate() {
    $.material.ripples();
  }

  render() {
    return (
      <div id="C02-A" className="container">
        <div className="left">
          <a href="javascript:void(0);" className="btn btn-default btn-fab">閉じる</a>
          <a href="javascript:void(0);" className="btn btn-default btn-fab back">&lt;</a>
        </div>
        <div className="right">
          <a href="javascript:void(0);" className="btn btn-default btn-fab next">&gt;</a>
        </div>
        <ul className="kanban">
          <li>看板の内容がリストで入ります</li>
        </ul>
      </div>
    );
  }
}
SampleC02Component.propTypes = {
  actions: PropTypes.object
};


function mapStateToProps(state, ownProps) {
  return {
  };
}

function mapDispatchToProps(dispatch, ownProps) {
  return {
    actions: bindActionCreators({}, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SampleC02Component);
