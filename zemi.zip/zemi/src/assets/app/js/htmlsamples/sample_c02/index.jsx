import React from "react";
import {render} from "react-dom";
import {Provider} from "react-redux";

import {log} from "common/utils";

import {configureStore} from "./store";
import SampleC02, {SampleC02Component} from "./containers/SampleC02";

const store = configureStore();


(($) => {
  $(() => {
    render(
      <Provider store={store}>
        <SampleC02 />
      </Provider>,
      document.getElementById("reactroot")
    );
  });
})(jQuery);
