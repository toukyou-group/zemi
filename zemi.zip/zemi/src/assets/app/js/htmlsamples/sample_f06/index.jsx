import React from "react";
import {render} from "react-dom";
import {Provider} from "react-redux";

import {log} from "common/utils";

import {configureStore} from "./store";
import SampleF06, {SampleF06Component} from "./containers/SampleF06";

const store = configureStore();


(($) => {
  $(() => {
    render(
      <Provider store={store}>
        <SampleF06 />
      </Provider>,
      document.getElementById("reactroot")
    );
  });
})(jQuery);
