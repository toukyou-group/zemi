import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {Provider, connect} from "react-redux";

import {log} from "common/utils";


export class SampleF06Component extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {

  }

  componentDidUpdate() {
    $.material.ripples();
  }

  render() {
    return (
      <div id="F06-CK" className="container">
        <div className="header">
          <a href="javascript:void(0);" className="btn back">&lt;教室へ</a>
          <h1>授業カルテ</h1>
          <ul>
            <li><a href="javascript:void(0);" className="btn">英語</a></li>
            <li><a href="javascript:void(0);" className="btn">数学</a></li>
            <li><a href="javascript:void(0);" className="btn">国語</a></li>
            <li><a href="javascript:void(0);" className="btn">理科</a></li>
            <li><a href="javascript:void(0);" className="btn">社会</a></li>
          </ul>
        </div>
        <div className="selection">
          <div className="gtg">
            <a href="javascript:void(0);" className="btn btn-deafult btn-fab btn-fab-mini">
              &lt;
            </a>
            <span className="gn-name">中3</span>
            <span className="gtg-name">12月号</span>
            <a href="javascript:void(0);" className="btn btn-deafult btn-fab btn-fab-mini">
              &gt;
            </a>
          </div>
          <div className="subject">
            英語
          </div>
          <div className="textbook">
            （光村図書）
          </div>
        </div>
        <div className="karte-header">
          <div className="karte-name">指数関数・対数関数</div>
          <ul>
            <li><a href="javascript:void(0);" className="btn">1</a></li>
            <li><a href="javascript:void(0);" className="btn">2</a></li>
            <li><a href="javascript:void(0);" className="btn">3</a></li>
            <li><a href="javascript:void(0);" className="btn">4</a></li>
            <li><a href="javascript:void(0);" className="btn">5</a></li>
            <li><a href="javascript:void(0);" className="btn">6</a></li>
            <li><a href="javascript:void(0);" className="btn">7</a></li>
            <li><a href="javascript:void(0);" className="btn">8</a></li>
          </ul>
        </div>
        <div className="karte">
          <div className="list-header">
            <div>&nbsp;</div>
            <div>ユニット</div>
            <div>講義</div>
            <div>演習</div>
          </div>
          <ul>
            <li className="list-item">
              <div>1</div>
              <div className="unit-name">連立方程式とその解、解き方 加減法 (1)</div>
              <div><a href="javascript:void(0);" className="btn">講義</a></div>
              <ul className="exercise">
                <li><a href="javascript:void(0);" className="btn">練習回</a></li>
                <li><a href="javascript:void(0);" className="btn">定着回</a></li>
                <li><a href="javascript:void(0);" className="btn">応用回</a></li>
                <li><a href="javascript:void(0);" className="btn">仕上げ<br />問題</a></li>
              </ul>
            </li>
            <li className="list-item">
              <div>2</div>
              <div className="unit-name">連立方程式とその解、解き方 加減法 (1)</div>
              <div><a href="javascript:void(0);" className="btn">講義</a></div>
              <ul className="exercise">
                <li><a href="javascript:void(0);" className="btn">練習回</a></li>
                <li><a href="javascript:void(0);" className="btn">定着回</a></li>
                <li><a href="javascript:void(0);" className="btn">応用回</a></li>
                <li><a href="javascript:void(0);" className="btn">仕上げ<br />問題</a></li>
              </ul>
            </li>
            <li className="list-item">
              <div>3</div>
              <div className="unit-name">連立方程式とその解、解き方 加減法 (1)</div>
              <div><a href="javascript:void(0);" className="btn">講義</a></div>
              <ul className="exercise">
                <li><a href="javascript:void(0);" className="btn">練習回</a></li>
                <li><a href="javascript:void(0);" className="btn">定着回</a></li>
                <li><a href="javascript:void(0);" className="btn">応用回</a></li>
                <li><a href="javascript:void(0);" className="btn">仕上げ<br />問題</a></li>
              </ul>
            </li>
            <li className="list-item">
              <div>4</div>
              <div className="unit-name">連立方程式とその解、解き方 加減法 (1)</div>
              <div><a href="javascript:void(0);" className="btn">講義</a></div>
              <ul className="exercise">
                <li><a href="javascript:void(0);" className="btn">練習回</a></li>
                <li><a href="javascript:void(0);" className="btn">定着回</a></li>
                <li><a href="javascript:void(0);" className="btn">応用回</a></li>
                <li><a href="javascript:void(0);" className="btn">仕上げ<br />問題</a></li>
              </ul>
            </li>
            <li className="list-item">
              <div>5</div>
              <div className="unit-name">連立方程式とその解、解き方 加減法 (1)</div>
              <div><a href="javascript:void(0);" className="btn">講義</a></div>
              <ul className="exercise">
                <li><a href="javascript:void(0);" className="btn">練習回</a></li>
                <li><a href="javascript:void(0);" className="btn">定着回</a></li>
                <li><a href="javascript:void(0);" className="btn">応用回</a></li>
                <li><a href="javascript:void(0);" className="btn">仕上げ<br />問題</a></li>
              </ul>
            </li>
            <li className="list-item">
              <div>6</div>
              <div className="unit-name">連立方程式とその解、解き方 加減法 (1)</div>
              <div><a href="javascript:void(0);" className="btn">講義</a></div>
              <ul className="exercise">
                <li><a href="javascript:void(0);" className="btn">練習回</a></li>
                <li><a href="javascript:void(0);" className="btn">定着回</a></li>
                <li><a href="javascript:void(0);" className="btn">応用回</a></li>
                <li><a href="javascript:void(0);" className="btn">仕上げ<br />問題</a></li>
              </ul>
            </li>
            <li className="list-item">
              <div>7</div>
              <div className="unit-name">連立方程式とその解、解き方 加減法 (1)</div>
              <div><a href="javascript:void(0);" className="btn">講義</a></div>
              <ul className="exercise">
                <li><a href="javascript:void(0);" className="btn">練習回</a></li>
                <li><a href="javascript:void(0);" className="btn">定着回</a></li>
                <li><a href="javascript:void(0);" className="btn">応用回</a></li>
                <li><a href="javascript:void(0);" className="btn">仕上げ<br />問題</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <div className="footer">
          <a href="javascript:void(0);" className="btn btn-raised">ニガテクリアレッスン</a>
          <a href="javascript:void(0);" className="btn btn-raised">応用回</a>
        </div>
        <a href="javascript:void(0);" className="btn btn-info btn-fab tete">定期テスト<br />やることリスト</a>
      </div>
    );
  }
}
SampleF06Component.propTypes = {
  actions: PropTypes.object
};


function mapStateToProps(state, ownProps) {
  return {
  };
}

function mapDispatchToProps(dispatch, ownProps) {
  return {
    actions: bindActionCreators({}, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SampleF06Component);
