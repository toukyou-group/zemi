import Constants from "common/constants/Constants";
module.exports = _.merge(Constants, {
  ACTIONS: {
    DUMMY: "DUMMY",
    ADDITEM: "ADDITEM",
    LOADING: "LOADING",
    SELECT: "SELECT"
  }
});
