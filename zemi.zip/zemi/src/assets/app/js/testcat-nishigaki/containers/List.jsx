import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {Provider, connect} from "react-redux";

import {log} from "common/utils";
import * as Actions from "testcat-nishigaki/actions";

import Item from "testcat-nishigaki/components/Item";
import ItemA from "testcat-nishigaki/components/ItemA";
import ItemB from "testcat-nishigaki/components/ItemB";
import ItemC from "testcat-nishigaki/components/ItemC";
import Simple from "testcat-nishigaki/components/Simple";

import Wrapper from "testcat-nishigaki/components/Wrapper";


export class ListComponent extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {

  }

  renderList() {
    return this.props.items.map((item) => {
      return (
        <ItemC key={item.id} id={item.id} name={item.name} onClick={e => this.props.actions.syncSelectItem(item)}/>
      );
    });
  }

  render() {
    return (
      <div>
        <Wrapper>
          test
        </Wrapper>
        <ul>
          {this.renderList()}
        </ul>
        <ul>
          <li>
            <button onClick={this.props.actions.syncTest1}>普通のActionCreator (直接ハンドラ)</button>
          </li>
          → 普通に同期処理
          <li>
            <button onClick={e => this.props.actions.syncTest1()}>普通のActionCreator (無名関数経由)</button>
          </li>
          → 普通に同期処理
          <li>
            <button onClick={this.props.actions.asyncTest1}>ThunkActionCreator、返り値なし (直接ハンドラ)</button>
          </li>
          → 非同期処理、引数にはReactEvent
          <li>
            <button onClick={e => this.props.actions.asyncTest1("patt 2")}>ThunkActionCreator、返り値なし (無名関数経由)</button>
          </li>
          → 非同期処理、引数は自由に指定できる
          <li>
            <button onClick={this.props.actions.asyncTest2}>returns ThunkActionCreator、ActionObjのようなObj返す (直接ハンドラ)
            </button>
          </li>
          → 非同期処理、引数にはReactEvent、返り値は使用できず
          <li>
            <button onClick={e => log(this.props.actions.asyncTest2("patt 3"))}>ThunkActionCreator、ActionObjのようなObj返す
              (無名関数経由)
            </button>
          </li>
          → 非同期処理、引数は自由に指定できる、返り値はDispatchされないけど値として実行時に返ってきて参照できる
          <li>
            <button onClick={this.props.actions.asyncTest3}>ThunkActionCreator、Promise返す (直接ハンドラ)</button>
          </li>
          → 非同期処理、引数にはReactEvent、返り値は使用できず
          <li>
            <button onClick={e => this.props.actions.asyncTest3("patt 4").then(() => { log("promise complete"); })}>
              ThunkActionCreator、Promise返す (無名関数経由)
            </button>
          </li>
          → 非同期処理、引数は自由に指定できる、返り値はDispatchされないけど値として実行時に返ってきてthenで繋げれる
        </ul>
        <Simple />
      </div>
    );
  }
}
ListComponent.propTypes = {
  actions: PropTypes.object,
  items: PropTypes.array
};


function mapStateToProps(state, ownProps) {
  return {
    items: state.items
  };
}

function mapDispatchToProps(dispatch, ownProps) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ListComponent);
