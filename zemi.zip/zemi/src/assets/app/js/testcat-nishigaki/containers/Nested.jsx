import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {Provider, connect} from "react-redux";

import * as Actions from "testcat-nishigaki/actions";


export class NestedComponent extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {

  }

  render() {
    return (
      <div>
        <div onClick={this.props.actions.syncDummy}>Users: {this.props.users.length}</div>
        <div onClick={e => {this.props.actions.syncDummy(new Error("asd"));}}>error</div>
      </div>
    );
  }
}
NestedComponent.propTypes = {
  actions: PropTypes.object,
  users: PropTypes.array
};


function mapStateToProps(state, ownProps) {
  return {
    users: state.users
  };
}

function mapDispatchToProps(dispatch, ownProps) {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(NestedComponent);
