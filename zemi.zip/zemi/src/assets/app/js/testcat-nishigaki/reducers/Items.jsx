import {handleAction, handleActions} from "redux-actions";
import {log, loadFromStorage, saveToStorage} from "common/utils";

import Constant from "testcat-nishigaki/constants/Constants";


const initialState = loadFromStorage(Constant.CACHED_REDUCERS.ITEMS) || [{
  id: 1,
  name: "item1"
}, {
  id: 2,
  name: "item2"
}, {
  id: 3,
  name: "item3"
}];


const dummyHdl = {
  next(state, action) {
    log("dummy success");
    log(action.type);
    return state;
  },
  throw(state, action) {
    log(action.type, "error");
    return state;
  }
};

const loadingHdl = {
  next(state, action) {
    log(`${action.type}`);
    return state;
  }
};

const addItemHdl = {
  next(state, action) {
    log(`Item reducer: action.type = ${action.type}`);
    log(`=> ${action.payload.num}`);
    let id = action.payload.num;
    let name = action.payload.nameSeed;
    state = [].concat(state, [{id: id, name: `${name} ${id}`}]);
    saveToStorage(Constant.CACHED_REDUCERS.ITEMS, state);
    return state;
  }
};

const selectHdl = {
  next(state, action) {
    log(`Item reducer: action.type = ${action.type}`);
    log(`=> ${action.payload.id}`);
    return state;
  }
};


export default handleActions({
  [Constant.ACTIONS.DUMMY]: dummyHdl,
  [Constant.ACTIONS.LOADING]: loadingHdl,
  [Constant.ACTIONS.ADDITEM]: addItemHdl,
  [Constant.ACTIONS.SELECT]: selectHdl
}, initialState);
