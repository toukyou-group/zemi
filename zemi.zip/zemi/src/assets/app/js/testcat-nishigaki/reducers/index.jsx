import {combineReducers} from "redux";
import items from "testcat-nishigaki/reducers/Items";
import users from "testcat-nishigaki/reducers/Users";


export default combineReducers({
  items,
  users
});
