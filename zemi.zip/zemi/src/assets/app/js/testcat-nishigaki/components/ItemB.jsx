import React, {Component, PropTypes} from "react";
import ItemA from "testcat-nishigaki/components/ItemA";


class ItemB extends ItemA {

  constructor(props) {
    super(props);
  }

}

ItemB.staticName = "ItemB";


export default ItemB;
