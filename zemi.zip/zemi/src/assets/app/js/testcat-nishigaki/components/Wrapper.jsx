import React, {Component, PropTypes} from "react";


class Wrapper extends Component {

  constructor(props) {
    super(props);
  }


  componentDidMount() {

  }

  render() {
    return (
      <ul>{this.props.children}</ul>
    );
  }
}
Wrapper.propTypes = {
  children: PropTypes.any
};


export default Wrapper;
