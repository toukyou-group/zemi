import React, {Component, PropTypes} from "react";
import Item from "testcat-nishigaki/components/Item";


class ItemA extends Item {

  constructor(props) {
    super(props);
  }

}

ItemA.staticName = "ItemA";


export default ItemA;
