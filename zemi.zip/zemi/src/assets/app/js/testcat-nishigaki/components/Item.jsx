import React, {Component, PropTypes} from "react";

import {log} from "common/utils";


class Item extends Component {

  constructor(props) {
    super(props);
  }


  componentDidMount() {
    log(Item.staticName);
  }


  render() {
    return (
      <li key={this.props.id} onClick={this.props.onClick}>{this.props.id} - {this.props.name}</li>
    );
  }
}
Item.propTypes = {
  id: PropTypes.number.isRequired,
  name: PropTypes.string,
  onClick: PropTypes.func.isRequired
};


Item.staticName = "Item";


export default Item;
