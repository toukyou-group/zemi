import React, {Component, PropTypes} from "react";
import ItemB from "testcat-nishigaki/components/ItemB";


class ItemC extends ItemB {

  constructor(props) {
    super(props);
  }

}

ItemC.staticName = "ItemC";


export default ItemC;
