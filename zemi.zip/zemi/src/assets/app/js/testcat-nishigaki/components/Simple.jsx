import React, {Component, PropTypes} from "react";

import Nested, {NestedComponent} from "testcat-nishigaki/containers/Nested";


class Simple extends Component {

  constructor(props) {
    super(props);
  }


  componentDidMount() {

  }

  render() {
    return (
      <div>
        <Nested />
      </div>
    );
  }
}


export default Simple;
