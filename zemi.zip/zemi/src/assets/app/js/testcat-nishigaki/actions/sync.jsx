import {createAction} from "redux-actions";
import Constants from "testcat-nishigaki/constants/Constants";


export const syncDummy = createAction(Constants.ACTIONS.DUMMY, item => item);
export const syncSelectItem = createAction(Constants.ACTIONS.SELECT, item => item);
export const syncAddItem = createAction(Constants.ACTIONS.ADDITEM, (nameSeed = "new", num = (Math.random() * 999) | 0) => {return {nameSeed, num}; });
export const syncLoading = createAction(Constants.ACTIONS.LOADING, val => val);
export const syncTest1 = createAction(Constants.ACTIONS.LOADING, val => val);
