import * as sync from "testcat-nishigaki/actions/sync";


export function getInfoPromise(dispatch) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      dispatch(sync.syncAddItem("new"));
      resolve(dispatch);
    }, 1000);
  });
}
