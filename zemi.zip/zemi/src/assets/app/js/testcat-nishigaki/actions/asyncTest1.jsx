import * as sync from "testcat-nishigaki/actions/sync";
import * as utils from "testcat-nishigaki/actions/utils";
import Constants from "testcat-nishigaki/constants/Constants";


export function asyncTest1(val) {
  return (dispatch, getState) => {
    dispatch(sync.syncLoading());
    utils.getInfoPromise(dispatch)
      .then(utils.getInfoPromise)
      .then(utils.getInfoPromise)
      .then(utils.getInfoPromise);
  };
}
