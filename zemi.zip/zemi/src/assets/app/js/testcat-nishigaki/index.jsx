import React from "react";
import {render} from "react-dom";
import {Provider} from "react-redux";

import {configureStore} from "testcat-nishigaki/store";
import List, {ListComponent} from "testcat-nishigaki/containers/List";

const store = configureStore();


(($) => {
  $(() => {
    render(
      <Provider store={store}>
        <List />
      </Provider>,
      document.getElementById("root")
    );
  });
})(jQuery);
