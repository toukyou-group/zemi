window.Promise = require("bluebird");
window.$ = window.jQuery = require("jquery");
window._ = require("lodash");
import SoundManager from "common/utils/SoundManager";
window.SoundManager = new SoundManager();
