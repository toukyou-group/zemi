var gulp = require("gulp");
var config = require("./gulp/gulpconfig");
var functions = require("./gulp/gulpfunctions");
var requireDir = require("require-dir");

//----------------------------------------------------------------------------------------------------
/// tasks
gulp.task("env-production",		function() { process.env.NODE_ENV = "production"; });
gulp.task("env-development",	function() { process.env.NODE_ENV = "development"; });
gulp.task("eslint",				function() { return functions.eslint(); });
gulp.task("stylint",			function() { return functions.stylint(); });
gulp.task("concat",				function() { return functions.concat(); });
gulp.task("clean",				function() { return functions.clean(); });
gulp.task("copy",				function() { return functions.copy(); });
gulp.task("babel",				function() { return functions.babel(); });
gulp.task("babel-watch",		function() { return functions.babel({watch: true}); });
gulp.task("babel-build",		function() { return functions.babel({watch: false, compress: true}); });
gulp.task("stylus",				function() { return functions.stylus(); });
gulp.task("stylus-build",		function() { return functions.stylus({compress: true}); });
gulp.task("sync",				function() { return functions.sync(); });
gulp.task("imagemin",			function() { return functions.imagemin(); });
gulp.task("jsdoc",				function() { return functions.jsdoc(); });
gulp.task("jsdoc2md",			function() { return functions.jsdoc2md(); });

gulp.task("watch",				function() {
	gulp.watch(config.tasks.eslint.src, ["eslint"]);
	gulp.watch(config.tasks.copy.watch, ["copy"]);
	gulp.watch([config.tasks.stylus.watch[0]], ["stylint", "stylus"]);
	gulp.watch(config.tasks.concat.reduce(function(last, val) { return last.concat(val.src); }, []), ['concat']);
});

//
gulp.task("default",	["eslint", "stylint", "concat", "copy", "babel-watch", "stylus", "watch", "sync"]);
gulp.task("build",		["env-production", "eslint", "stylint", "concat", "copy", "babel-build", "stylus-build", "imagemin"]);
gulp.task("watchonly",	["eslint", "stylint", "concat", "copy", "babel-watch", "stylus", "watch"]);


//----------------------------------------------------------------------------------------------------
/// require-dir
requireDir("./gulp/custom", {recursive: true});
