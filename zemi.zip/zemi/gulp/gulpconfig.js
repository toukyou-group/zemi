var historyApiFallback = require('connect-history-api-fallback');

var config = {
	useJshint: false,
	paths: {
		src: "./src/",
		dest: "./build/",
		docs: "./docs/"
	},
	tasks: {}
};
config.paths.srcWatch = config.paths.src.replace("./", "");

config.tasks = {
	sync: {
		port: 3000,
		server: {
			baseDir: config.paths.dest,
			directory: true
			//middleware: [historyApiFallback()]
		},
		ui: {
			port: 3001
		},
		startPath: "/",
		ghostMode: false
	},
	babel: [
		{
		src: config.paths.src + "assets/app/js/INIinitialSetting/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "INIinitialSetting.js"
	},{
		src: config.paths.src + "assets/app/js/testcat-nishigaki/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "testcat-nishigaki.js"
	}, {
		src: config.paths.src + "assets/app/js/myroom/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "myroom.js"
	}, {
		src: config.paths.src + "assets/app/js/htmlsamples/sample_b09/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "htmlsamples/sample_b09.js"
	}, {
		src: config.paths.src + "assets/app/js/htmlsamples/sample_c02/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "htmlsamples/sample_c02.js"
	}, {
		src: config.paths.src + "assets/app/js/htmlsamples/sample_f03/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "htmlsamples/sample_f03.js"
	}, {
		src: config.paths.src + "assets/app/js/htmlsamples/sample_f06/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "htmlsamples/sample_f06.js"
	}, {
		src: config.paths.src + "assets/app/js/initialSetting/index.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "initialsetting.js"
	}, {
		src: config.paths.src + "assets/app/js/libs.jsx",
		paths: ["./node_modules", config.paths.src + "assets/app/js"],
		dest: config.paths.dest + "assets/app/js/",
		file: "libs.js"
	}],
	concat: [/*{
	 dest: config.paths.src + "s_common/js/",
	 concat: "libs.js",
	 src: [
		config.paths.src + "s_common/js/libs/jquery-1.9.1.js",
		config.paths.src + "s_common/js/libs/jquery.easing.js",
		config.paths.src + "s_common/js/libs/jquery.transit.min.js",
		config.paths.src + "s_common/js/libs/jquery.utils.js",
	]
	}*/],
	eslint: {
		src: [
			config.paths.src + "**/*.jsx"
		]
	},
	stylus: {
		src: [
			config.paths.src + "**/!(_)*.styl"
		],
		dest: config.paths.dest,
		watch: config.paths.srcWatch + "**/*.styl"
	},
	stylint: {
		src: [config.paths.src + "**/*.styl"]
	},
	copy: {
		src: [config.paths.src + "**/*.{html,htm,css,js,ico,json,xml,woff,woff2,ttf,eot,mp4,webm,jpeg,jpg,gif,png,svg,map,mp3}"],
		dest: config.paths.dest,
		watch: [config.paths.srcWatch + "**/*.{html,htm,css,js,ico,json,xml,woff,woff2,ttf,eot,mp4,webm,jpeg,jpg,gif,png,svg,map,mp3}"]
	},
	imagemin: {
		src: [config.paths.src + "**/*.{png,jpg,gif,svg}"],
		dest: config.paths.dest
	},
	jsdoc: {
		src: config.paths.src + "**/*.jsx",
		config: {
			opts: {
				destination: config.paths.docs + "jsdoc/"
			}
		}
	},
	jsdoc2md: {
		src: config.paths.src + "**/*.jsx",
		dest: config.paths.docs + "jsdoc/",
		destFile: "classes.md"
	}
};


module.exports = config;
