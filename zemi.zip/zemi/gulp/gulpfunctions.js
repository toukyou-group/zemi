var gulp = require("gulp");
var plumber = require("gulp-plumber");
var gutil = require("gulp-util");
var gulpif = require("gulp-if");
var sourcemaps = require("gulp-sourcemaps");
var source = require("vinyl-source-stream");
var buffer = require("vinyl-buffer");
var concat = require("gulp-concat");
var stream = require("event-stream");
var sync = require("browser-sync");
var browserify = require("browserify");
var babelify = require("babelify");
var watchify = require("watchify");
var uglify = require("gulp-uglify");
var eslint = require("gulp-eslint");
var jshint = require("gulp-jshint");
var stylish = require("jshint-stylish");
var stylus = require("gulp-stylus");
var postcss = require("gulp-postcss");
var stylint = require('gulp-stylint');
var autoprefixer = require("autoprefixer");
var config = require("./gulpconfig");
var assign = require('lodash').assign;
var changed = require('gulp-changed');
var imagemin = require('gulp-imagemin');
var del = require('del');
var jsdoc = require("gulp-jsdoc3");
var gulpJsdoc2md = require('gulp-jsdoc-to-markdown');
var nib = require("nib");
var _ = require("lodash");



//----------------------------------------------------------------------------------------------------
/// functions
var functions = {
	sync: function() {
		sync(config.tasks.sync);
	},
	babel: function(options) {
		options = options || {};
		options.watch = options.watch || false;

		var babel = function(obj, doWatch) {
			doWatch = doWatch || false;

			var browserifyOpts = {
				entries: [obj.src],
				transform: [babelify.configure({
					presets: ["es2015-loose", "react"]
				})],
				extensions: [".js", ".jsx", ".es6"],
				paths: obj.paths,
				debug: true
			};
			if(doWatch) browserifyOpts = assign({}, watchify.args, browserifyOpts);
			var b = browserify(browserifyOpts);

			var compile = function() {
				gutil.log("Starting", "'" + gutil.colors.cyan("browserify") + "'", "file " + gutil.colors.magenta(obj.file), "...");
				var startTime = (new Date()).getTime();
				return b.bundle(function(err) {
					var elapsedTime = Math.round((((new Date()).getTime() - startTime) / 1000) * 100) / 100;
					if(err) {
						gutil.log("Finished", "'" + gutil.colors.cyan("browserify") + "'", "file " + gutil.colors.magenta(obj.file), gutil.colors.red("error"));
						console.log(err.toString());
						console.log("-------------------------");
						console.log(err.codeFrame);
						console.log("-------------------------");
					} else {
						gutil.log("Finished", "'" + gutil.colors.cyan("browserify") + "'", "file " + gutil.colors.magenta(obj.file), "after", gutil.colors.magenta(elapsedTime + " s"));
					}
				})
					.pipe(plumber())
					.pipe(source(obj.file))
					.pipe(buffer())
					.pipe(gulpif(options.compress !== true, sourcemaps.init({loadMaps: true})))
					.pipe(gulpif(options.compress === true, uglify()))
					.pipe(gulpif(options.compress !== true, sourcemaps.write("./")))
					.pipe(gulp.dest(obj.dest))
					.pipe(sync.stream({once: true}));
			};
			if(doWatch) {
				b = watchify(b);
				b.on('update', function(id) {
					gutil.log("Browserify update: " + id);
					compile();
				});
			}
			return compile();
		};
		for(var i = 0, iLen = config.tasks.babel.length; i < iLen; i++) {
			babel(config.tasks.babel[i], options.watch);
		}
		return gutil.noop();
	},
	concat: function(options) {
		options = options || {};
		var arr = [];
		for(var i = 0, iLen = config.tasks.concat.length; i < iLen; i++) {
			arr.push(
				(function(i) {
					var src = gulp.src(config.tasks.concat[i].src)
						.pipe(plumber())
						.pipe(concat(config.tasks.concat[i].concat));
					if(config.useJshint) src = src.pipe(jshint()).pipe(jshint.reporter('default'));
					if(options.build) src = src.pipe(uglify());
					return src.pipe(gulp.dest(config.tasks.concat[i].dest));
				})(i)
			);
		}
		return stream.merge(arr);
	},
	stylus: function(options) {
		options = options || {};
		if(!config.tasks.stylus) return gutil.noop();
		return gulp.src(config.tasks.stylus.src)
			.pipe(plumber())
			.pipe(gulpif(options.compress !== true, sourcemaps.init()))
			.pipe(stylus(_.assign(options, { use: [nib()] })))
			.pipe(postcss([autoprefixer({browsers: ['last 3 versions']})]))
			.pipe(gulpif(options.compress !== true, sourcemaps.write("./")))
			.pipe(gulp.dest(config.tasks.stylus.dest))
			.pipe(sync.stream({match: '**/*.css'}));
	},
	eslint: function(options) {
		options = options || {};
		return gulp.src(config.tasks.eslint.src)
			.pipe(plumber())
			.pipe(eslint())
			.pipe(eslint.format());
	},
	stylint: function(options) {
		options = options || {};
		return gulp.src(config.tasks.stylint.src)
			.pipe(plumber())
			.pipe(stylint())
			.pipe(stylint.reporter());
	},
	copy: function() {
		return gulp.src(config.tasks.copy.src)
			.pipe(changed(config.tasks.copy.dest))
			.pipe(gulp.dest(config.tasks.copy.dest))
			.pipe(sync.stream());
	},
	clean: function() {
		return del(config.paths.dest);
	},
	imagemin: function() {
		return gulp.src(config.tasks.imagemin.src)
			.pipe(imagemin())
			.pipe(gulp.dest(config.tasks.imagemin.dest))
			.pipe(sync.stream());
	},
	jsdoc: function() {
		return gulp.src(config.tasks.jsdoc.src, {read: false})
			.pipe(jsdoc(config.tasks.jsdoc.config));
	},
	jsdoc2md: function() {
		return gulp.src(config.tasks.jsdoc2md.src)
			.pipe(concat(config.tasks.jsdoc2md.destFile))
			.pipe(gulpJsdoc2md({"no-gfm": true}))
			.pipe(gulp.dest(config.tasks.jsdoc2md.dest));
	}
};


module.exports = functions;
