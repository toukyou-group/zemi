var gulp = require('gulp');
var config = require("../gulpconfig");
var functions = require("../gulpfunctions");


// customize config
/*
config.tasks.sync.startPath = "/s_index.html?path=./contents/01_SAMPLE_UI_BUTTON/01_SAMPLE_UI_BUTTON_index.html";
*/


// customize tasks
/*
gulp.task("custom", function() {
	console.log(config.tasks.sync);
});
*/