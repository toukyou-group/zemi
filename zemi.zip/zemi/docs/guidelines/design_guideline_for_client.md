# JS(ロジック)設計ガイドライン
## 変更履歴

## 目次
- 全体像
 - 概要コンポーネント図
 - 基本シーケンス
- 各コンポーネントの責務
- 設計の流れ

#### 概要コンポーネント図
 ![概要コンポーネント図](./gaiyo-component.png "")

#### 基本シーケンス図
 ![基本シーケンス図](./kihon-sequence.png "")
 - 概要クラス図

### 各コンポーネントの責務

#### Container
- 画面制御のための部品を定義するクラス
- Containerは階層構造を持つ
  - CategoryContainer:カテゴリ単位のContainer
  - ScreenContainer:画面単位のContainer
- 基本的には画面単位で作成する
- Componentに必要な情報をpropsで渡す
  - Actions、ThunkActionsをconnect経由で持ち、Componentにハンドラーとして渡す
  - storeのstateをconnect経由で持ち、Componentにpropsとして渡す
  - 画面単位のContainerから直接ハンドラーを渡せないComponentがある場合には、子Containerを作成してもよい。
- 子Containerを作成する場合、connectの際にstateを渡してはいけない。Actions、ThunkActionsのみ渡す。

#### Component
- 画面表示のための部品を定義するクラス
- Componentは階層構造を持つ
  - Componentの子としてContainerを持たせてもよい
- stateは持たせず、必要な情報は全てpropsで渡す
  - propsで受け取ったデータを元に、表示状態を決める
- ボタンなど、Componentによってはユーザ操作を受け付けるものが存在する
  - ユーザ操作を受け付けるComponentはユーザ操作を受け付けて実行するfunction(Action)をpropsとして受け取る

#### ThunkAction
- Actionを発行する前のロジックを担当するfunction
  - APIリクエストをするかどうか、その後どのActionを発行するかなどを決めるロジックを実装
  - APIリクエストのロジックそのものもThunkAction内に記載する

#### Action
- Reducerに通知するアクションを定義するオブジェクト
- TYPE、payload、meta、errorを持つ
  - TYPEには文字列またはシンボルでアクションのタイプを定義する
  - payloadにはreducerに渡すためのデータを持つ。errorがtrueの場合、エラーオブジェクトを持つ。
  - errorがエラーの状態を持つ
- 実装にはredux-actionsを利用する
  - 各ActionはActionCreatorによって生成される
  - 共通エラー以外は redux-actions の throw ハンドラで処理する

#### Reducer
- 現在の状態とActionから新しい状態を生成するfunction
- 作成するReducerは以下のいずれかに分類
  - APIReducer:APIのレスポンス単位の状態変化
  - ScreenReducer:1つの画面単位の状態変化
  - CategoryReducer:1つのカテゴリ単位の状態変化
  - CommonReducer:カテゴリ間をまたぐ状態変化
  - ErrorReducer:共通エラー(client通信、BAE通信に伴うエラー)に関する状態変化
- APIのレスポンスをフィルタするのであればそのロジックを実装する
- カテゴリをまたいで保持しなければいけない情報はReducerでsessionStorageに保持する
  - SessionStorageに対する読み書きはReducer内のみで完結させる
  - ReducerのInitialStateでSessionStorageから初期状態を読み込む
- Reducerのreturn前に新しい状態をStorageに書き込む

#### Store(State)
- アプリケーションの状態を保持するオブジェクト
- 以下の単位でブロックを持ち、それぞれに対応するReducerによって更新される
  - APIState:APIのレスポンス単位
  - ScreenState:1つの画面単位
  - CategoryState:1つのカテゴリ単位
  - CommonState:カテゴリ間をまたぐ単位
  - ErrorState:共通エラー(client通信、BAE通信に伴うエラー)単位

### 設計の大まかな流れ
 - 基本設計・詳細設計の流れとコンポーネントの関係性を示す。
 - シーケンス図、画面遷移図、画面設計書、機能設計書（画面設計書内）、データフロー図（オプション）とのざっくりとした関係性を説明する。
  - 設計書テンプレートをMSEからもらってから整理する
 - 設計時の注意事項も合わせて記載する



