# zemi-plus-web


## 1 - プロジェクトの準備


### 1 - 1 必要なソフトウェアのインストール

- npm ver 0.12以上、無い場合は [https://nodejs.org](https://nodejs.org)
- gulp、無い場合は `sudo npm install -g gulp`




### 1 - 2 必要なnpmパッケージをインストール

プロジェクトフォルダーに移動して、
プロジェクトに必要なパッケージをインストール。

	$ cd path/to/projectdir
	$ npm install

**※注意**

** 1.`npm install` 後初回の `gulp` でうまく表示されない場合があります。**

→ browserify のコンパイルが完了する前に、browsersyncが走ってしまうのが原因で、ブラウザをリロードすれば問題普通に見れるようになります。

** 2. nodejsのバージョンが古いと（ver 0.12未満）、`gulp` 実行時にpipeエラーがでて、stylusがうまくコンパイルされません。**

→ その場合、nodejsを最新にしてください。


### 1 - 3 gulpの実行

##### Browser Sync付きのgulpを起動するには次のコマンドを実行。

	$ cd path/to/projectdir
	$ gulp

gulpで実行されている内容は：
- babel/browserifyでjavascriptのコンパイル
- concatでjQueryなどのライブラリを1つのファイルに結合
- stylusでcssをコンパイル
- 変更をwatchして、ファイルが編集されたら、自動的にコンパイル処理が走る仕組み
- Browser Syncの起動とwatch

##### Watchのみでgulpを起動するには次のコマンドを実行。

	$ gulp watchonly

##### 納品ファイルを作成する場合は次のコマンドを実行。

	$ gulp clean
	$ gulp build

- cleanでbuildフォルダーを削除
- buildでproductionファイルをコンパイル

##### jsdoc生成用コマンド。

	$ gulp jsdoc

- `docs/jsdoc/`フォルダーにjsdocを生成

##### markdown形式jsdoc生成用コマンド。

	$ gulp jsdoc2md

- `docs/jsdoc/classes.md`ファイルにjsdoc書き出し



### 1 - 4 gulpの独自のカスタム設定

BrowserSyncのポート番号など、プロジェクトファイルを変更せず、開発環境毎にgulpのconfigを変更する事ができます。

`gulp/custom/customsample.js` を複製し、`config` オブジェクトの値を変更する事で、デフォルトの値が上書きされた状態になります。


